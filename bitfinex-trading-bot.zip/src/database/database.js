/**
 * SQLite Database Manager
 * Stores trades, orders, performance metrics, and bot state
 */

const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');
const logger = require('../utils/logger');

class Database {
  constructor(dbPath = './data/trading.db') {
    this.dbPath = dbPath;
    this.db = null;
  }

  async init() {
    // Ensure data directory exists
    const dir = path.dirname(this.dbPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    return new Promise((resolve, reject) => {
      this.db = new sqlite3.Database(this.dbPath, (err) => {
        if (err) {
          logger.error('Database connection failed:', err);
          reject(err);
        } else {
          logger.info(`✅ Database connected: ${this.dbPath}`);
          this.createTables().then(resolve).catch(reject);
        }
      });
    });
  }

  async createTables() {
    const tables = [
      // Trades table
      `CREATE TABLE IF NOT EXISTS trades (
        id TEXT PRIMARY KEY,
        timestamp TEXT NOT NULL,
        symbol TEXT NOT NULL,
        side TEXT NOT NULL,
        price REAL NOT NULL,
        amount REAL NOT NULL,
        total REAL NOT NULL,
        paper INTEGER NOT NULL DEFAULT 1,
        strategy TEXT NOT NULL,
        order_id TEXT,
        status TEXT DEFAULT 'filled',
        pnl REAL DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,

      // Orders table
      `CREATE TABLE IF NOT EXISTS orders (
        id TEXT PRIMARY KEY,
        timestamp TEXT NOT NULL,
        symbol TEXT NOT NULL,
        side TEXT NOT NULL,
        type TEXT NOT NULL,
        price REAL,
        amount REAL NOT NULL,
        filled_amount REAL DEFAULT 0,
        status TEXT DEFAULT 'active',
        paper INTEGER NOT NULL DEFAULT 1,
        strategy TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,

      // Performance metrics table
      `CREATE TABLE IF NOT EXISTS performance (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        date TEXT NOT NULL,
        strategy TEXT NOT NULL,
        symbol TEXT NOT NULL,
        total_trades INTEGER DEFAULT 0,
        winning_trades INTEGER DEFAULT 0,
        losing_trades INTEGER DEFAULT 0,
        total_pnl REAL DEFAULT 0,
        total_volume REAL DEFAULT 0,
        max_drawdown REAL DEFAULT 0,
        sharpe_ratio REAL DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,

      // Bot state table
      `CREATE TABLE IF NOT EXISTS bot_state (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,

      // Price history for backtesting
      `CREATE TABLE IF NOT EXISTS price_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        symbol TEXT NOT NULL,
        timestamp INTEGER NOT NULL,
        open REAL NOT NULL,
        high REAL NOT NULL,
        low REAL NOT NULL,
        close REAL NOT NULL,
        volume REAL NOT NULL,
        UNIQUE(symbol, timestamp)
      )`,

      // Grid levels for grid strategy
      `CREATE TABLE IF NOT EXISTS grid_levels (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        strategy_id TEXT NOT NULL,
        price REAL NOT NULL,
        side TEXT NOT NULL,
        amount REAL NOT NULL,
        status TEXT DEFAULT 'active',
        order_id TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`
    ];

    const indexes = [
      'CREATE INDEX IF NOT EXISTS idx_trades_symbol ON trades(symbol)',
      'CREATE INDEX IF NOT EXISTS idx_trades_timestamp ON trades(timestamp)',
      'CREATE INDEX IF NOT EXISTS idx_trades_strategy ON trades(strategy)',
      'CREATE INDEX IF NOT EXISTS idx_price_history_symbol_time ON price_history(symbol, timestamp)',
      'CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status)'
    ];

    for (const sql of [...tables, ...indexes]) {
      await this.run(sql);
    }

    logger.info('✅ Database tables created');
  }

  run(sql, params = []) {
    return new Promise((resolve, reject) => {
      this.db.run(sql, params, function(err) {
        if (err) reject(err);
        else resolve({ id: this.lastID, changes: this.changes });
      });
    });
  }

  get(sql, params = []) {
    return new Promise((resolve, reject) => {
      this.db.get(sql, params, (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });
  }

  all(sql, params = []) {
    return new Promise((resolve, reject) => {
      this.db.all(sql, params, (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  }

  // ==================== TRADE OPERATIONS ====================

  async recordTrade(trade) {
    const sql = `INSERT INTO trades (id, timestamp, symbol, side, price, amount, total, paper, strategy, order_id, status, pnl)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;

    await this.run(sql, [
      trade.id,
      trade.timestamp,
      trade.symbol,
      trade.side,
      trade.price,
      trade.amount,
      trade.total,
      trade.paper ? 1 : 0,
      trade.strategy,
      trade.orderId || null,
      trade.status || 'filled',
      trade.pnl || 0
    ]);

    logger.debug(`Trade recorded: ${trade.id}`);
  }

  async getTrades(symbol, limit = 100, paper = null) {
    let sql = 'SELECT * FROM trades WHERE symbol = ?';
    const params = [symbol];

    if (paper !== null) {
      sql += ' AND paper = ?';
      params.push(paper ? 1 : 0);
    }

    sql += ' ORDER BY timestamp DESC LIMIT ?';
    params.push(limit);

    return this.all(sql, params);
  }

  async getTradeStats(symbol, strategy, days = 30) {
    const sql = `
      SELECT 
        COUNT(*) as total_trades,
        SUM(CASE WHEN pnl > 0 THEN 1 ELSE 0 END) as winning_trades,
        SUM(CASE WHEN pnl < 0 THEN 1 ELSE 0 END) as losing_trades,
        SUM(pnl) as total_pnl,
        SUM(total) as total_volume,
        AVG(pnl) as avg_pnl,
        MAX(pnl) as best_trade,
        MIN(pnl) as worst_trade
      FROM trades 
      WHERE symbol = ? AND strategy = ? 
      AND timestamp >= datetime('now', '-${days} days')
    `;

    return this.get(sql, [symbol, strategy]);
  }

  // ==================== ORDER OPERATIONS ====================

  async recordOrder(order) {
    const sql = `INSERT OR REPLACE INTO orders (id, timestamp, symbol, side, type, price, amount, filled_amount, status, paper, strategy)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;

    await this.run(sql, [
      order.id,
      order.timestamp,
      order.symbol,
      order.side,
      order.type,
      order.price,
      order.amount,
      order.filledAmount || 0,
      order.status,
      order.paper ? 1 : 0,
      order.strategy
    ]);
  }

  async updateOrderStatus(orderId, status, filledAmount = null) {
    let sql = 'UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP';
    const params = [status];

    if (filledAmount !== null) {
      sql += ', filled_amount = ?';
      params.push(filledAmount);
    }

    sql += ' WHERE id = ?';
    params.push(orderId);

    await this.run(sql, params);
  }

  async getActiveOrders(symbol) {
    return this.all(
      'SELECT * FROM orders WHERE symbol = ? AND status IN ("active", "partially_filled")',
      [symbol]
    );
  }

  // ==================== PERFORMANCE METRICS ====================

  async recordPerformance(metrics) {
    const sql = `INSERT INTO performance 
                 (date, strategy, symbol, total_trades, winning_trades, losing_trades, total_pnl, total_volume, max_drawdown, sharpe_ratio)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                 ON CONFLICT(date, strategy, symbol) DO UPDATE SET
                 total_trades = excluded.total_trades,
                 winning_trades = excluded.winning_trades,
                 losing_trades = excluded.losing_trades,
                 total_pnl = excluded.total_pnl,
                 total_volume = excluded.total_volume,
                 max_drawdown = excluded.max_drawdown,
                 sharpe_ratio = excluded.sharpe_ratio`;

    await this.run(sql, [
      metrics.date,
      metrics.strategy,
      metrics.symbol,
      metrics.totalTrades,
      metrics.winningTrades,
      metrics.losingTrades,
      metrics.totalPnl,
      metrics.totalVolume,
      metrics.maxDrawdown,
      metrics.sharpeRatio
    ]);
  }

  async getPerformance(strategy, symbol, days = 30) {
    return this.all(
      `SELECT * FROM performance 
       WHERE strategy = ? AND symbol = ? 
       AND date >= date('now', '-${days} days')
       ORDER BY date DESC`,
      [strategy, symbol]
    );
  }

  // ==================== PRICE HISTORY ====================

  async saveCandles(symbol, candles) {
    const stmt = this.db.prepare(
      `INSERT OR REPLACE INTO price_history (symbol, timestamp, open, high, low, close, volume)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    );

    for (const candle of candles) {
      stmt.run([
        symbol,
        candle.timestamp,
        candle.open,
        candle.high,
        candle.low,
        candle.close,
        candle.volume
      ]);
    }

    stmt.finalize();
  }

  async getCandles(symbol, timeframe = '1h', limit = 100) {
    return this.all(
      `SELECT * FROM price_history 
       WHERE symbol = ? 
       ORDER BY timestamp DESC 
       LIMIT ?`,
      [symbol, limit]
    );
  }

  // ==================== BOT STATE ====================

  async setState(key, value) {
    const sql = `INSERT INTO bot_state (key, value, updated_at) 
                 VALUES (?, ?, CURRENT_TIMESTAMP)
                 ON CONFLICT(key) DO UPDATE SET 
                 value = excluded.value, 
                 updated_at = CURRENT_TIMESTAMP`;

    await this.run(sql, [key, JSON.stringify(value)]);
  }

  async getState(key, defaultValue = null) {
    const row = await this.get('SELECT value FROM bot_state WHERE key = ?', [key]);
    return row ? JSON.parse(row.value) : defaultValue;
  }

  // ==================== GRID LEVELS ====================

  async saveGridLevel(level) {
    const sql = `INSERT INTO grid_levels (strategy_id, price, side, amount, status, order_id)
                 VALUES (?, ?, ?, ?, ?, ?)`;

    const result = await this.run(sql, [
      level.strategyId,
      level.price,
      level.side,
      level.amount,
      level.status || 'active',
      level.orderId || null
    ]);

    return result.id;
  }

  async getGridLevels(strategyId, status = null) {
    let sql = 'SELECT * FROM grid_levels WHERE strategy_id = ?';
    const params = [strategyId];

    if (status) {
      sql += ' AND status = ?';
      params.push(status);
    }

    return this.all(sql, params);
  }

  async updateGridLevel(id, updates) {
    const fields = Object.keys(updates).map(k => `${k} = ?`).join(', ');
    const sql = `UPDATE grid_levels SET ${fields}, updated_at = CURRENT_TIMESTAMP WHERE id = ?`;

    await this.run(sql, [...Object.values(updates), id]);
  }

  close() {
    if (this.db) {
      this.db.close((err) => {
        if (err) logger.error('Error closing database:', err);
        else logger.info('Database connection closed');
      });
    }
  }
}

module.exports = Database;
