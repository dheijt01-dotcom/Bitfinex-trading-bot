/**
 * Bitfinex WebSocket v2 Client
 * Handles real-time market data, order book updates, and trade feeds
 * WebSocket limits: max 25 channels per connection, 20 connections/min on pub WS
 */

const WebSocket = require('ws');
const EventEmitter = require('events');
const logger = require('../utils/logger');

class BitfinexWebSocket extends EventEmitter {
  constructor(config = {}) {
    super();
    this.url = config.url || process.env.BITFINEX_PUB_WS_URL || 'wss://api-pub.bitfinex.com/ws/2';
    this.symbol = config.symbol || 'tBTCUSD';
    this.reconnectInterval = config.reconnectInterval || 5000;
    this.maxReconnectAttempts = config.maxReconnectAttempts || 10;
    this.heartbeatInterval = config.heartbeatInterval || 15000;

    this.ws = null;
    this.isConnected = false;
    this.reconnectAttempts = 0;
    this.channels = new Map(); // channelId -> { channel, symbol, handler }
    this.subscriptions = new Set();
    this.heartbeatTimer = null;
    this.reconnectTimer = null;
    this.orderBook = { bids: {}, asks: {}, seq: 0 };
  }

  async connect() {
    return new Promise((resolve, reject) => {
      try {
        logger.info(`Connecting to Bitfinex WebSocket: ${this.url}`);

        this.ws = new WebSocket(this.url, {
          handshakeTimeout: 10000,
          perMessageDeflate: false
        });

        this.ws.on('open', () => {
          logger.info('✅ WebSocket connected');
          this.isConnected = true;
          this.reconnectAttempts = 0;
          this.startHeartbeat();
          this.resubscribe();
          this.emit('connected');
          resolve();
        });

        this.ws.on('message', (data) => {
          this.handleMessage(data);
        });

        this.ws.on('error', (error) => {
          logger.error('WebSocket error:', error.message);
          this.emit('error', error);
          if (!this.isConnected) {
            reject(error);
          }
        });

        this.ws.on('close', (code, reason) => {
          logger.warn(`WebSocket closed: ${code} - ${reason}`);
          this.isConnected = false;
          this.stopHeartbeat();
          this.emit('disconnected', { code, reason });
          this.scheduleReconnect();
        });

      } catch (error) {
        reject(error);
      }
    });
  }

  disconnect() {
    logger.info('Disconnecting WebSocket...');
    this.stopHeartbeat();

    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }

    if (this.ws) {
      this.ws.close(1000, 'Client disconnect');
      this.ws = null;
    }

    this.isConnected = false;
    this.channels.clear();
  }

  scheduleReconnect() {
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      logger.error('Max reconnect attempts reached. Giving up.');
      this.emit('maxReconnectReached');
      return;
    }

    this.reconnectAttempts++;
    const delay = Math.min(this.reconnectInterval * this.reconnectAttempts, 60000);

    logger.info(`Reconnecting in ${delay}ms (attempt ${this.reconnectAttempts}/${this.maxReconnectAttempts})`);

    this.reconnectTimer = setTimeout(() => {
      this.connect().catch(error => {
        logger.error('Reconnect failed:', error.message);
      });
    }, delay);
  }

  startHeartbeat() {
    this.heartbeatTimer = setInterval(() => {
      if (this.isConnected && this.ws.readyState === WebSocket.OPEN) {
        this.ws.send(JSON.stringify({ event: 'ping' }));
      }
    }, this.heartbeatInterval);
  }

  stopHeartbeat() {
    if (this.heartbeatTimer) {
      clearInterval(this.heartbeatTimer);
      this.heartbeatTimer = null;
    }
  }

  send(data) {
    if (this.isConnected && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(data));
    } else {
      logger.warn('WebSocket not connected, cannot send message');
    }
  }

  /**
   * Subscribe to ticker channel
   */
  subscribeTicker(symbol = this.symbol) {
    const sub = {
      event: 'subscribe',
      channel: 'ticker',
      symbol
    };
    this.subscriptions.add(JSON.stringify(sub));
    this.send(sub);
    logger.info(`Subscribed to ticker: ${symbol}`);
  }

  /**
   * Subscribe to trades channel
   */
  subscribeTrades(symbol = this.symbol) {
    const sub = {
      event: 'subscribe',
      channel: 'trades',
      symbol
    };
    this.subscriptions.add(JSON.stringify(sub));
    this.send(sub);
    logger.info(`Subscribed to trades: ${symbol}`);
  }

  /**
   * Subscribe to order book (L2)
   */
  subscribeOrderBook(symbol = this.symbol, precision = 'P0', length = 25) {
    const sub = {
      event: 'subscribe',
      channel: 'book',
      symbol,
      prec: precision,
      len: length
    };
    this.subscriptions.add(JSON.stringify(sub));
    this.send(sub);
    logger.info(`Subscribed to order book: ${symbol} (${precision})`);
  }

  /**
   * Subscribe to candles
   */
  subscribeCandles(symbol = this.symbol, timeframe = '1m') {
    const sub = {
      event: 'subscribe',
      channel: 'candles',
      key: `trade:${timeframe}:${symbol}`
    };
    this.subscriptions.add(JSON.stringify(sub));
    this.send(sub);
    logger.info(`Subscribed to candles: ${symbol} (${timeframe})`);
  }

  resubscribe() {
    logger.info(`Resubscribing to ${this.subscriptions.size} channels...`);
    for (const sub of this.subscriptions) {
      this.send(JSON.parse(sub));
    }
  }

  handleMessage(data) {
    try {
      const message = JSON.parse(data.toString());

      // Handle events
      if (message.event) {
        this.handleEvent(message);
        return;
      }

      // Handle channel data [CHAN_ID, DATA]
      if (Array.isArray(message)) {
        const [chanId, ...payload] = message;

        if (payload[0] === 'hb') {
          // Heartbeat, ignore
          return;
        }

        const channel = this.channels.get(chanId);
        if (!channel) {
          // Initial snapshot for order book
          if (Array.isArray(payload[0]) && Array.isArray(payload[0][0])) {
            this.handleOrderBookSnapshot(chanId, payload[0]);
          }
          return;
        }

        switch (channel.channel) {
          case 'ticker':
            this.handleTicker(channel.symbol, payload);
            break;
          case 'trades':
            this.handleTrade(channel.symbol, payload);
            break;
          case 'book':
            this.handleOrderBookUpdate(chanId, payload);
            break;
          case 'candles':
            this.handleCandle(channel.key, payload);
            break;
        }
      }

    } catch (error) {
      logger.error('Error parsing WebSocket message:', error.message);
    }
  }

  handleEvent(message) {
    switch (message.event) {
      case 'subscribed':
        this.channels.set(message.chanId, {
          channel: message.channel,
          symbol: message.symbol,
          key: message.key,
          pair: message.pair
        });
        logger.info(`Subscribed to ${message.channel} (ID: ${message.chanId})`);
        this.emit('subscribed', message);
        break;

      case 'unsubscribed':
        this.channels.delete(message.chanId);
        logger.info(`Unsubscribed from channel ${message.chanId}`);
        break;

      case 'error':
        logger.error(`WebSocket error event: ${message.msg} (code: ${message.code})`);
        this.emit('wsError', message);
        break;

      case 'info':
        logger.info(`WebSocket info: ${JSON.stringify(message)}`);
        if (message.code === 20051) {
          // Server requesting reconnect
          logger.warn('Server requesting reconnect');
          this.ws.close();
        }
        break;

      case 'pong':
        // Heartbeat response
        break;

      case 'conf':
        logger.info('Configuration updated');
        break;

      default:
        logger.debug(`Unhandled event: ${message.event}`);
    }
  }

  handleTicker(symbol, data) {
    // Ticker data: [BID, BID_SIZE, ASK, ASK_SIZE, DAILY_CHANGE, DAILY_CHANGE_RELATIVE, LAST_PRICE, VOLUME, HIGH, LOW]
    const ticker = {
      symbol,
      bid: data[0],
      bidSize: data[1],
      ask: data[2],
      askSize: data[3],
      dailyChange: data[4],
      dailyChangeRelative: data[5],
      lastPrice: data[6],
      volume: data[7],
      high: data[8],
      low: data[9],
      timestamp: Date.now()
    };

    this.emit('ticker', ticker);
  }

  handleTrade(symbol, data) {
    // Trade data: [ID, MTS, AMOUNT, PRICE] or 'te' event
    if (data[0] === 'te' || data[0] === 'tu') {
      const trade = {
        symbol,
        id: data[1],
        timestamp: data[2],
        amount: data[3],
        price: data[4],
        type: data[3] > 0 ? 'buy' : 'sell'
      };
      this.emit('trade', trade);
    }
  }

  handleOrderBookSnapshot(chanId, snapshot) {
    // snapshot is array of [PRICE, COUNT, AMOUNT]
    this.orderBook = { bids: {}, asks: {}, seq: 0 };

    for (const [price, count, amount] of snapshot) {
      if (count > 0) {
        if (amount > 0) {
          this.orderBook.bids[price] = { price, count, amount };
        } else {
          this.orderBook.asks[price] = { price, count, amount: Math.abs(amount) };
        }
      }
    }

    this.emit('orderBookSnapshot', this.getOrderBookSnapshot());
  }

  handleOrderBookUpdate(chanId, payload) {
    // payload: [PRICE, COUNT, AMOUNT]
    const [price, count, amount] = payload;

    if (count === 0) {
      // Remove price level
      delete this.orderBook.bids[price];
      delete this.orderBook.asks[price];
    } else {
      if (amount > 0) {
        this.orderBook.bids[price] = { price, count, amount };
        delete this.orderBook.asks[price];
      } else {
        this.orderBook.asks[price] = { price, count, amount: Math.abs(amount) };
        delete this.orderBook.bids[price];
      }
    }

    this.orderBook.seq++;
    this.emit('orderBookUpdate', this.getOrderBookSnapshot());
  }

  handleCandle(key, data) {
    // Candle data: [MTS, OPEN, CLOSE, HIGH, LOW, VOLUME]
    if (Array.isArray(data[0])) {
      // Historical candles
      const candles = data.map(c => ({
        timestamp: c[0],
        open: c[1],
        close: c[2],
        high: c[3],
        low: c[4],
        volume: c[5]
      }));
      this.emit('candles', { key, candles });
    } else {
      // Single candle update
      const candle = {
        timestamp: data[0],
        open: data[1],
        close: data[2],
        high: data[3],
        low: data[4],
        volume: data[5]
      };
      this.emit('candle', { key, candle });
    }
  }

  getOrderBookSnapshot() {
    const bids = Object.values(this.orderBook.bids)
      .sort((a, b) => b.price - a.price)
      .slice(0, 25);

    const asks = Object.values(this.orderBook.asks)
      .sort((a, b) => a.price - b.price)
      .slice(0, 25);

    return { bids, asks, seq: this.orderBook.seq };
  }

  getBestBidAsk() {
    const snapshot = this.getOrderBookSnapshot();
    return {
      bestBid: snapshot.bids[0]?.price || 0,
      bestAsk: snapshot.asks[0]?.price || 0,
      spread: (snapshot.asks[0]?.price || 0) - (snapshot.bids[0]?.price || 0)
    };
  }
}

module.exports = BitfinexWebSocket;
