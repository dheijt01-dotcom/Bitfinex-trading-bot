/**
 * Bitfinex REST API v2 Client
 * Handles authentication, rate limiting, and request signing
 */

const crypto = require('crypto');
const axios = require('axios');
const logger = require('../utils/logger');

class BitfinexAPI {
  constructor(config = {}) {
    this.apiKey = config.apiKey || process.env.BITFINEX_API_KEY;
    this.apiSecret = config.apiSecret || process.env.BITFINEX_API_SECRET;
    this.baseUrl = config.baseUrl || process.env.BITFINEX_API_URL || 'https://api.bitfinex.com/v2';
    this.pubUrl = config.pubUrl || process.env.BITFINEX_PUB_URL || 'https://api-pub.bitfinex.com/v2';
    this.nonce = Date.now() * 1000;
    this.lastRequestTime = 0;
    this.minRequestInterval = 600; // ~100 req/min max to stay safe
  }

  /**
   * Rate limit helper
   */
  async rateLimit() {
    const now = Date.now();
    const timeSinceLastRequest = now - this.lastRequestTime;

    if (timeSinceLastRequest < this.minRequestInterval) {
      await this.sleep(this.minRequestInterval - timeSinceLastRequest);
    }

    this.lastRequestTime = Date.now();
  }

  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /**
   * Generate authentication headers for private endpoints
   */
  getAuthHeaders(path, body = {}) {
    this.nonce++;
    const nonce = this.nonce.toString();
    const payload = `/api/v2${path}${nonce}${JSON.stringify(body)}`;

    const signature = crypto
      .createHmac('sha384', this.apiSecret)
      .update(payload)
      .digest('hex');

    return {
      'bfx-nonce': nonce,
      'bfx-apikey': this.apiKey,
      'bfx-signature': signature,
      'Content-Type': 'application/json'
    };
  }

  /**
   * Make authenticated request
   */
  async authRequest(method, path, body = {}) {
    await this.rateLimit();

    const url = `${this.baseUrl}${path}`;
    const headers = this.getAuthHeaders(path, body);

    try {
      const response = await axios({
        method,
        url,
        headers,
        data: body,
        timeout: 30000
      });

      return response.data;
    } catch (error) {
      if (error.response) {
        logger.error(`API Error: ${error.response.status} - ${JSON.stringify(error.response.data)}`);
        throw new Error(`Bitfinex API Error: ${error.response.data[2] || error.response.statusText}`);
      }
      throw error;
    }
  }

  /**
   * Make public request
   */
  async pubRequest(path) {
    await this.rateLimit();

    const url = `${this.pubUrl}${path}`;

    try {
      const response = await axios({
        method: 'GET',
        url,
        timeout: 30000
      });

      return response.data;
    } catch (error) {
      if (error.response) {
        logger.error(`Public API Error: ${error.response.status} - ${JSON.stringify(error.response.data)}`);
        throw new Error(`Bitfinex Public API Error: ${error.response.statusText}`);
      }
      throw error;
    }
  }

  // ==================== PUBLIC ENDPOINTS ====================

  /**
   * Get ticker data
   * Returns: [BID, BID_SIZE, ASK, ASK_SIZE, DAILY_CHANGE, DAILY_CHANGE_RELATIVE, LAST_PRICE, VOLUME, HIGH, LOW]
   */
  async getTicker(symbol = 'tBTCUSD') {
    return this.pubRequest(`/ticker/${symbol}`);
  }

  /**
   * Get multiple tickers
   */
  async getTickers(symbols = ['tBTCUSD']) {
    const symbolsParam = symbols.join(',');
    return this.pubRequest(`/tickers?symbols=${symbolsParam}`);
  }

  /**
   * Get candlestick data
   * Timeframes: 1m, 5m, 15m, 30m, 1h, 3h, 6h, 12h, 1D, 7D, 14D, 1M
   */
  async getCandles(symbol = 'tBTCUSD', timeframe = '1h', limit = 100, section = 'hist') {
    return this.pubRequest(`/candles/trade:${timeframe}:${symbol}/${section}?limit=${limit}`);
  }

  /**
   * Get order book
   * Precisions: P0 (2 decimals), P1 (1 decimal), P2 (0 decimals), P3 (1/10), P4 (1/100), R0 (raw)
   */
  async getOrderBook(symbol = 'tBTCUSD', precision = 'P0', len = 25) {
    return this.pubRequest(`/book/${symbol}/${precision}?len=${len}`);
  }

  /**
   * Get recent trades
   */
  async getTrades(symbol = 'tBTCUSD', limit = 100) {
    return this.pubRequest(`/trades/${symbol}/hist?limit=${limit}`);
  }

  /**
   * Get platform status
   */
  async getPlatformStatus() {
    return this.pubRequest('/platform/status');
  }

  // ==================== AUTHENTICATED ENDPOINTS ====================

  /**
   * Get wallets/balances
   */
  async getWallets() {
    return this.authRequest('POST', '/auth/r/wallets');
  }

  /**
   * Get active orders
   */
  async getActiveOrders() {
    return this.authRequest('POST', '/auth/r/orders');
  }

  /**
   * Get order history
   */
  async getOrderHistory(symbol = 'tBTCUSD', limit = 100) {
    return this.authRequest('POST', `/auth/r/orders/${symbol}/hist`, { limit });
  }

  /**
   * Get active positions
   */
  async getPositions() {
    return this.authRequest('POST', '/auth/r/positions');
  }

  /**
   * Get trades history
   */
  async getTradesHistory(symbol = 'tBTCUSD', limit = 100) {
    return this.authRequest('POST', `/auth/r/trades/${symbol}/hist`, { limit });
  }

  /**
   * Place an order
   * Types: EXCHANGE MARKET, EXCHANGE LIMIT, EXCHANGE STOP, EXCHANGE STOP LIMIT, EXCHANGE TRAILING STOP, EXCHANGE FOK, EXCHANGE IOC
   */
  async placeOrder({ symbol, amount, price = 0, type = 'EXCHANGE LIMIT', flags = 0 }) {
    const body = {
      type,
      symbol,
      amount: amount.toString(),
      price: price.toString(),
      flags
    };

    return this.authRequest('POST', '/auth/w/order/submit', body);
  }

  /**
   * Cancel an order
   */
  async cancelOrder(orderId) {
    return this.authRequest('POST', '/auth/w/order/cancel', { id: orderId });
  }

  /**
   * Cancel all orders
   */
  async cancelAllOrders() {
    return this.authRequest('POST', '/auth/w/order/cancel/all');
  }

  /**
   * Get account info
   */
  async getAccountInfo() {
    return this.authRequest('POST', '/auth/r/info/user');
  }

  /**
   * Get funding info (for margin trading)
   */
  async getFundingInfo(symbol = 'fUSD') {
    return this.pubRequest(`/funding/stats/${symbol}/hist?limit=100`);
  }
}

module.exports = BitfinexAPI;
