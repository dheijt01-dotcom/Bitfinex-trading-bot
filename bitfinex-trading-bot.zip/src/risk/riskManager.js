/**
 * Risk Management Module
 * Enforces position limits, stop-losses, daily loss limits, and emergency stops
 */

const EventEmitter = require('events');
const logger = require('../utils/logger');

class RiskManager extends EventEmitter {
  constructor(config = {}) {
    super();

    this.config = {
      maxDailyLossPct: config.maxDailyLossPct || 5,
      maxPositionSizePct: config.maxPositionSizePct || 10,
      maxPositionValue: config.maxPositionValue || 1000,
      stopLossPct: config.stopLossPct || 3,
      takeProfitPct: config.takeProfitPct || 5,
      maxOpenPositions: config.maxOpenPositions || 3,
      maxTradesPerHour: config.maxTradesPerHour || 10,
      killSwitchEnabled: config.killSwitchEnabled !== false,
      ...config
    };

    this.dailyStats = {
      profit: 0,
      loss: 0,
      trades: 0,
      lastReset: Date.now()
    };

    this.positions = new Map();
    this.hourlyTrades = [];
    this.isTradingHalted = false;
    this.portfolioValue = 0;
  }

  /**
   * Check if trading is allowed
   */
  canTrade(portfolioValue = this.portfolioValue) {
    this.portfolioValue = portfolioValue;

    // Reset daily stats if new day
    this.checkDailyReset();

    if (this.isTradingHalted) {
      return { allowed: false, reason: 'Trading halted - manual intervention required' };
    }

    // Check daily loss limit
    const totalDailyPnl = this.dailyStats.profit + this.dailyStats.loss;
    const dailyLossLimit = -(this.config.maxDailyLossPct / 100) * portfolioValue;

    if (totalDailyPnl <= dailyLossLimit) {
      this.triggerKillSwitch('Daily loss limit reached');
      return { allowed: false, reason: `Daily loss limit reached: ${totalDailyPnl.toFixed(2)}` };
    }

    // Check hourly trade limit
    this.cleanHourlyTrades();
    if (this.hourlyTrades.length >= this.config.maxTradesPerHour) {
      return { allowed: false, reason: `Hourly trade limit reached: ${this.config.maxTradesPerHour}` };
    }

    // Check max open positions
    if (this.positions.size >= this.config.maxOpenPositions) {
      return { allowed: false, reason: `Max open positions reached: ${this.config.maxOpenPositions}` };
    }

    return { allowed: true };
  }

  /**
   * Validate a new order
   */
  validateOrder(order, portfolioValue = this.portfolioValue) {
    const { side, amount, price, symbol } = order;
    const positionValue = Math.abs(amount) * price;
    const positionPct = portfolioValue > 0 ? (positionValue / portfolioValue) * 100 : 0;

    // Check max position size
    if (positionValue > this.config.maxPositionValue) {
      return {
        valid: false,
        reason: `Position value $${positionValue.toFixed(2)} exceeds max $${this.config.maxPositionValue}`
      };
    }

    if (positionPct > this.config.maxPositionSizePct) {
      return {
        valid: false,
        reason: `Position ${positionPct.toFixed(2)}% exceeds max ${this.config.maxPositionSizePct}%`
      };
    }

    // Check if we already have a position in this symbol
    if (this.positions.has(symbol) && side === 'buy') {
      const existing = this.positions.get(symbol);
      const newTotalValue = (existing.amount * existing.price) + positionValue;
      if (newTotalValue > this.config.maxPositionValue) {
        return {
          valid: false,
          reason: 'Adding to position would exceed max position value'
        };
      }
    }

    return { valid: true };
  }

  /**
   * Check stop-loss and take-profit for a position
   */
  checkExitConditions(position, currentPrice) {
    const { entryPrice, side, amount } = position;

    if (side === 'long') {
      const lossPct = ((entryPrice - currentPrice) / entryPrice) * 100;
      const profitPct = ((currentPrice - entryPrice) / entryPrice) * 100;

      if (lossPct >= this.config.stopLossPct) {
        return { shouldExit: true, reason: 'stop_loss', exitPrice: currentPrice };
      }

      if (profitPct >= this.config.takeProfitPct) {
        return { shouldExit: true, reason: 'take_profit', exitPrice: currentPrice };
      }
    } else {
      // Short position
      const lossPct = ((currentPrice - entryPrice) / entryPrice) * 100;
      const profitPct = ((entryPrice - currentPrice) / entryPrice) * 100;

      if (lossPct >= this.config.stopLossPct) {
        return { shouldExit: true, reason: 'stop_loss', exitPrice: currentPrice };
      }

      if (profitPct >= this.config.takeProfitPct) {
        return { shouldExit: true, reason: 'take_profit', exitPrice: currentPrice };
      }
    }

    return { shouldExit: false };
  }

  /**
   * Record a new position
   */
  addPosition(symbol, side, amount, price) {
    const position = {
      symbol,
      side,
      amount,
      entryPrice: price,
      timestamp: Date.now(),
      highestPrice: price,
      lowestPrice: price
    };

    if (this.positions.has(symbol)) {
      // Average down/up
      const existing = this.positions.get(symbol);
      const totalAmount = existing.amount + amount;
      const avgPrice = ((existing.amount * existing.entryPrice) + (amount * price)) / totalAmount;

      existing.amount = totalAmount;
      existing.entryPrice = avgPrice;
      existing.highestPrice = Math.max(existing.highestPrice, price);
      existing.lowestPrice = Math.min(existing.lowestPrice, price);
    } else {
      this.positions.set(symbol, position);
    }

    logger.info(`Position added: ${symbol} ${side} ${amount} @ $${price}`);
  }

  /**
   * Close a position
   */
  closePosition(symbol, exitPrice) {
    const position = this.positions.get(symbol);
    if (!position) return null;

    const pnl = position.side === 'long'
      ? (exitPrice - position.entryPrice) * position.amount
      : (position.entryPrice - exitPrice) * position.amount;

    const pnlPct = position.side === 'long'
      ? ((exitPrice - position.entryPrice) / position.entryPrice) * 100
      : ((position.entryPrice - exitPrice) / position.entryPrice) * 100;

    this.recordTrade(pnl);
    this.positions.delete(symbol);

    logger.info(`Position closed: ${symbol} P&L: $${pnl.toFixed(2)} (${pnlPct.toFixed(2)}%)`);

    return { pnl, pnlPct, position };
  }

  /**
   * Record trade P&L
   */
  recordTrade(pnl) {
    this.dailyStats.trades++;
    this.hourlyTrades.push(Date.now());

    if (pnl >= 0) {
      this.dailyStats.profit += pnl;
    } else {
      this.dailyStats.loss += pnl;
    }

    this.emit('tradeRecorded', { pnl, dailyStats: { ...this.dailyStats } });
  }

  /**
   * Update position with current price (for trailing stop)
   */
  updatePositionPrice(symbol, currentPrice) {
    const position = this.positions.get(symbol);
    if (!position) return null;

    if (position.side === 'long') {
      if (currentPrice > position.highestPrice) {
        position.highestPrice = currentPrice;
      }
    } else {
      if (currentPrice < position.lowestPrice) {
        position.lowestPrice = currentPrice;
      }
    }

    // Check trailing stop
    const trailingStopPct = this.config.stopLossPct;

    if (position.side === 'long') {
      const drawdown = ((position.highestPrice - currentPrice) / position.highestPrice) * 100;
      if (drawdown >= trailingStopPct) {
        return { triggered: true, reason: 'trailing_stop', exitPrice: currentPrice };
      }
    } else {
      const drawdown = ((currentPrice - position.lowestPrice) / position.lowestPrice) * 100;
      if (drawdown >= trailingStopPct) {
        return { triggered: true, reason: 'trailing_stop', exitPrice: currentPrice };
      }
    }

    return { triggered: false };
  }

  /**
   * Emergency kill switch
   */
  triggerKillSwitch(reason) {
    this.isTradingHalted = true;
    logger.error(`🚨 KILL SWITCH TRIGGERED: ${reason}`);
    this.emit('killSwitch', { reason, timestamp: new Date().toISOString() });
  }

  /**
   * Resume trading (manual override)
   */
  resumeTrading() {
    this.isTradingHalted = false;
    this.resetDailyStats();
    logger.info('✅ Trading resumed');
    this.emit('tradingResumed');
  }

  /**
   * Reset daily statistics
   */
  resetDailyStats() {
    this.dailyStats = {
      profit: 0,
      loss: 0,
      trades: 0,
      lastReset: Date.now()
    };
    logger.info('Daily stats reset');
  }

  checkDailyReset() {
    const now = Date.now();
    const lastReset = this.dailyStats.lastReset;
    const msInDay = 24 * 60 * 60 * 1000;

    if (now - lastReset >= msInDay) {
      this.resetDailyStats();
    }
  }

  cleanHourlyTrades() {
    const oneHourAgo = Date.now() - (60 * 60 * 1000);
    this.hourlyTrades = this.hourlyTrades.filter(t => t > oneHourAgo);
  }

  getStatus() {
    this.checkDailyReset();
    this.cleanHourlyTrades();

    return {
      isTradingHalted: this.isTradingHalted,
      dailyStats: { ...this.dailyStats },
      openPositions: Array.from(this.positions.entries()).map(([symbol, pos]) => ({
        symbol,
        ...pos
      })),
      hourlyTradeCount: this.hourlyTrades.length,
      config: { ...this.config }
    };
  }
}

module.exports = RiskManager;
