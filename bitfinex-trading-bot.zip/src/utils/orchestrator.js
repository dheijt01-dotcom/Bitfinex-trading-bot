/**
 * Bot Orchestrator - Manages strategy lifecycle and coordination
 */

const EventEmitter = require('events');
const logger = require('./logger');
const GridStrategy = require('../strategies/grid');
const DCAStrategy = require('../strategies/dca');
const TrendStrategy = require('../strategies/trend');
const ScalpingStrategy = require('../strategies/scalping');
const MeanReversionStrategy = require('../strategies/meanReversion');

class BotOrchestrator extends EventEmitter {
  constructor(config) {
    super();
    this.config = config;
    this.isRunning = false;
    this.strategy = null;
    this.strategyName = config.strategy || 'grid';
    this.symbol = config.symbol || 'tBTCUSD';
    this.paperTrading = config.paperTrading !== false;
    this.enableLive = config.enableLive === true;
  }

  async start() {
    if (this.isRunning) {
      logger.warn('Bot is already running');
      return;
    }

    logger.info(`Starting bot with strategy: ${this.strategyName.toUpperCase()}`);
    logger.info(`Symbol: ${this.symbol}`);
    logger.info(`Mode: ${this.paperTrading ? 'PAPER TRADING' : 'LIVE TRADING'}`);

    // Initialize strategy
    this.strategy = this.createStrategy(this.strategyName);

    // Setup event listeners
    this.strategy.on('buy', (data) => this.handleBuy(data));
    this.strategy.on('sell', (data) => this.handleSell(data));
    this.strategy.on('error', (error) => this.handleError(error));
    this.strategy.on('status', (status) => this.emit('status', status));

    // Start strategy
    this.isRunning = true;
    await this.strategy.start();

    this.emit('started', { strategy: this.strategyName, symbol: this.symbol });
    logger.info('✅ Bot started successfully');
  }

  async stop() {
    if (!this.isRunning) return;

    logger.info('Stopping bot...');
    this.isRunning = false;

    if (this.strategy) {
      await this.strategy.stop();
    }

    this.emit('stopped');
    logger.info('✅ Bot stopped');
  }

  createStrategy(name) {
    const strategyConfig = {
      api: this.config.api,
      wsClient: this.config.wsClient,
      db: this.config.db,
      riskManager: this.config.riskManager,
      symbol: this.symbol,
      paperTrading: this.paperTrading,
      enableLive: this.enableLive
    };

    switch (name.toLowerCase()) {
      case 'grid':
        return new GridStrategy({
          ...strategyConfig,
          upperPrice: parseFloat(process.env.GRID_UPPER_PRICE) || 105000,
          lowerPrice: parseFloat(process.env.GRID_LOWER_PRICE) || 95000,
          gridCount: parseInt(process.env.GRID_COUNT) || 20,
          totalInvestment: parseFloat(process.env.GRID_INVESTMENT_USD) || 5000
        });

      case 'dca':
        return new DCAStrategy({
          ...strategyConfig,
          initialAmount: parseFloat(process.env.DCA_INITIAL_AMOUNT) || 0.01,
          safetyOrders: JSON.parse(process.env.DCA_SAFETY_ORDERS || '[{"dropPct":3,"multiplier":1.5}]'),
          takeProfitPct: parseFloat(process.env.DCA_TAKE_PROFIT_PCT) || 5
        });

      case 'trend':
        return new TrendStrategy({
          ...strategyConfig,
          fastPeriod: parseInt(process.env.TREND_FAST_PERIOD) || 10,
          slowPeriod: parseInt(process.env.TREND_SLOW_PERIOD) || 30,
          timeframe: process.env.TREND_TIMEFRAME || '1h'
        });

      case 'scalping':
        return new ScalpingStrategy(strategyConfig);

      case 'meanreversion':
        return new MeanReversionStrategy(strategyConfig);

      default:
        throw new Error(`Unknown strategy: ${name}`);
    }
  }

  async handleBuy(data) {
    logger.info(`📈 BUY signal: ${JSON.stringify(data)}`);

    if (this.paperTrading) {
      await this.recordPaperTrade('buy', data);
    } else if (this.enableLive) {
      await this.executeLiveTrade('buy', data);
    }

    this.emit('trade', { type: 'buy', ...data });
  }

  async handleSell(data) {
    logger.info(`📉 SELL signal: ${JSON.stringify(data)}`);

    if (this.paperTrading) {
      await this.recordPaperTrade('sell', data);
    } else if (this.enableLive) {
      await this.executeLiveTrade('sell', data);
    }

    this.emit('trade', { type: 'sell', ...data });
  }

  async recordPaperTrade(side, data) {
    const trade = {
      id: `paper_${Date.now()}`,
      timestamp: new Date().toISOString(),
      symbol: this.symbol,
      side,
      price: data.price,
      amount: data.amount,
      total: data.price * data.amount,
      paper: true,
      strategy: this.strategyName
    };

    await this.config.db.recordTrade(trade);
    logger.info(`📝 Paper trade recorded: ${side.toUpperCase()} ${data.amount} @ $${data.price}`);
  }

  async executeLiveTrade(side, data) {
    try {
      const amount = side === 'buy' ? data.amount : -data.amount;
      const order = await this.config.api.placeOrder({
        symbol: this.symbol,
        amount,
        price: data.price,
        type: 'EXCHANGE LIMIT'
      });

      logger.info(`✅ Live order placed: ${side.toUpperCase()} ${data.amount} @ $${data.price}`);
      logger.info(`Order ID: ${order.id}`);

      await this.config.db.recordTrade({
        id: order.id,
        timestamp: new Date().toISOString(),
        symbol: this.symbol,
        side,
        price: data.price,
        amount: data.amount,
        total: data.price * data.amount,
        paper: false,
        strategy: this.strategyName,
        orderId: order.id
      });

    } catch (error) {
      logger.error(`❌ Live trade failed: ${error.message}`);
      this.emit('error', error);
    }
  }

  handleError(error) {
    logger.error('Strategy error:', error);
    this.emit('error', error);
  }

  getStatus() {
    return {
      isRunning: this.isRunning,
      strategy: this.strategyName,
      symbol: this.symbol,
      paperTrading: this.paperTrading,
      liveTrading: this.enableLive,
      strategyStatus: this.strategy ? this.strategy.getStatus() : null
    };
  }
}

module.exports = BotOrchestrator;
