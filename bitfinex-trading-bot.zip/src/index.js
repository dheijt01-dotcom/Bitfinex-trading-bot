/**
 * Bitfinex Trading Bot - Main Entry Point
 * Production-ready crypto trading bot for Google Cloud VM deployment
 */

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const cron = require('node-cron');
const path = require('path');

const logger = require('./utils/logger');
const Database = require('./database/database');
const BitfinexAPI = require('./api/bitfinex');
const BitfinexWebSocket = require('./api/websocket');
const RiskManager = require('./risk/riskManager');
const BotOrchestrator = require('./utils/orchestrator');
const dashboardRoutes = require('./dashboard/routes');

const app = express();
const PORT = process.env.PORT || 3000;

// Security middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://cdnjs.cloudflare.com"],
      scriptSrc: ["'self'", "'unsafe-inline'", "https://cdnjs.cloudflare.com", "https://cdn.jsdelivr.net"],
      imgSrc: ["'self'", "data:", "https:"],
    }
  }
}));
app.use(cors());
app.use(compression());
app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, 'dashboard', 'public')));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  message: { error: 'Too many requests, please try again later.' }
});
app.use('/api/', limiter);

// Initialize components
let botOrchestrator = null;
let wsClient = null;

async function initializeApp() {
  try {
    logger.info('🚀 Starting Bitfinex Trading Bot...');
    logger.info(`Environment: ${process.env.NODE_ENV || 'development'}`);
    logger.info(`Paper Trading: ${process.env.PAPER_TRADING === 'true' ? 'ENABLED' : 'DISABLED'}`);
    logger.info(`Live Trading: ${process.env.ENABLE_LIVE_TRADING === 'true' ? 'ENABLED' : 'DISABLED'}`);

    // Initialize database
    const db = new Database(process.env.DATABASE_PATH || './data/trading.db');
    await db.init();
    logger.info('✅ Database initialized');

    // Initialize Bitfinex API
    const api = new BitfinexAPI({
      apiKey: process.env.BITFINEX_API_KEY,
      apiSecret: process.env.BITFINEX_API_SECRET,
      baseUrl: process.env.BITFINEX_API_URL,
      pubUrl: process.env.BITFINEX_PUB_URL
    });
    logger.info('✅ Bitfinex API client initialized');

    // Initialize WebSocket for real-time data
    wsClient = new BitfinexWebSocket({
      url: process.env.BITFINEX_PUB_WS_URL || 'wss://api-pub.bitfinex.com/ws/2',
      symbol: process.env.TRADING_SYMBOL || 'tBTCUSD'
    });
    await wsClient.connect();
    logger.info('✅ WebSocket connected');

    // Initialize risk manager
    const riskManager = new RiskManager({
      maxDailyLossPct: parseFloat(process.env.MAX_DAILY_LOSS_PCT) || 5,
      maxPositionSizePct: parseFloat(process.env.MAX_POSITION_SIZE_PCT) || 10,
      stopLossPct: parseFloat(process.env.STOP_LOSS_PCT) || 3,
      takeProfitPct: parseFloat(process.env.TAKE_PROFIT_PCT) || 5,
      maxPositionValue: parseFloat(process.env.MAX_POSITION_VALUE_USD) || 1000
    });
    logger.info('✅ Risk manager initialized');

    // Initialize bot orchestrator
    botOrchestrator = new BotOrchestrator({
      api,
      wsClient,
      db,
      riskManager,
      symbol: process.env.TRADING_SYMBOL || 'tBTCUSD',
      strategy: process.env.TRADING_STRATEGY || 'grid',
      paperTrading: process.env.PAPER_TRADING === 'true',
      enableLive: process.env.ENABLE_LIVE_TRADING === 'true'
    });
    logger.info('✅ Bot orchestrator initialized');

    // Setup dashboard routes with access to bot components
    app.use('/api', dashboardRoutes({
      botOrchestrator,
      db,
      api,
      riskManager,
      wsClient
    }));

    // Health check endpoint
    app.get('/health', (req, res) => {
      res.json({
        status: 'ok',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        wsConnected: wsClient ? wsClient.isConnected : false,
        botRunning: botOrchestrator ? botOrchestrator.isRunning : false,
        paperTrading: process.env.PAPER_TRADING === 'true',
        liveTrading: process.env.ENABLE_LIVE_TRADING === 'true'
      });
    });

    // Serve dashboard
    app.get('/', (req, res) => {
      res.sendFile(path.join(__dirname, 'dashboard', 'public', 'index.html'));
    });

    // Error handling
    app.use((err, req, res, next) => {
      logger.error('Express error:', err);
      res.status(500).json({ error: 'Internal server error' });
    });

    // Start HTTP server
    app.listen(PORT, '0.0.0.0', () => {
      logger.info(`🌐 Dashboard running on http://0.0.0.0:${PORT}`);
      logger.info(`📊 Access your bot dashboard at: http://YOUR_VM_IP:${PORT}`);
    });

    // Start the bot
    await botOrchestrator.start();

    // Schedule daily stats reset
    cron.schedule('0 0 * * *', () => {
      logger.info('Resetting daily stats...');
      riskManager.resetDailyStats();
    });

    // Graceful shutdown
    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);

  } catch (error) {
    logger.error('Failed to initialize app:', error);
    process.exit(1);
  }
}

async function gracefulShutdown() {
  logger.info('Received shutdown signal, gracefully shutting down...');

  if (botOrchestrator) {
    await botOrchestrator.stop();
  }

  if (wsClient) {
    wsClient.disconnect();
  }

  logger.info('Shutdown complete');
  process.exit(0);
}

initializeApp();
