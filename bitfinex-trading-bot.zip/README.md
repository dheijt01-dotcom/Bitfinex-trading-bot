# Bitfinex Trading Bot - Google Cloud Deployment

Complete crypto trading bot voor Bitfinex, klaar voor deployment op Google Cloud VM.

## 📁 Project Structuur

```
bitfinex-trading-bot/
├── src/
│   ├── index.js              # Hoofd applicatie
│   ├── api/
│   │   ├── bitfinex.js       # Bitfinex REST API client
│   │   └── websocket.js      # Bitfinex WebSocket client
│   ├── strategies/
│   │   ├── grid.js           # Grid Trading strategie
│   │   ├── dca.js            # Dollar-Cost Averaging
│   │   ├── trend.js          # Trend Following (MA/RSI)
│   │   ├── scalping.js       # Scalping strategie
│   │   └── meanReversion.js  # Mean Reversion (Bollinger)
│   ├── risk/
│   │   └── riskManager.js    # Risk management & kill switch
│   ├── database/
│   │   └── database.js       # SQLite database
│   ├── dashboard/
│   │   └── public/
│   │       └── index.html    # Web dashboard
│   └── utils/
│       ├── logger.js         # Winston logger
│       └── orchestrator.js   # Bot orchestrator
├── scripts/
│   ├── setup.sh              # Lokale setup
│   ├── deploy.sh             # GCP deployment (HOOFD SCRIPT)
│   ├── destroy.sh            # Alles verwijderen
│   ├── status.sh             # Status check
│   └── update.sh             # Bot updaten
├── Dockerfile                # Docker image
├── docker-compose.yml        # Productie Docker Compose
├── docker-compose.dev.yml    # Ontwikkeling Docker Compose
├── package.json              # Node.js dependencies
├── .env.example              # Voorbeeld configuratie
└── .gitignore
```

---

## 🚀 Snelle Start (3 stappen)

### Stap 1: Lokale Setup

```bash
# Clone of download dit project
cd bitfinex-trading-bot

# Run setup script
./scripts/setup.sh
```

Dit installeert:
- Node.js dependencies
- Maakt `data/`, `logs/`, `backups/` mappen aan
- Maakt een `.env` bestand aan

### Stap 2: Configureer API Keys

```bash
# Bewerk het .env bestand
nano .env
```

Vul in:
```
BITFINEX_API_KEY=je_echte_api_key
BITFINEX_API_SECRET=je_echte_api_secret
PAPER_TRADING=true        # BELANGRIJK: Begin altijd met paper trading!
```

**Hoe krijg je API keys?**
1. Log in op [Bitfinex](https://www.bitfinex.com)
2. Ga naar **Account > API**
3. Maak een nieuwe API key aan
4. Geef rechten: **Orders**, **Wallets**, **Account Info**
5. **Sla de secret op** — deze zie je maar 1 keer!

### Stap 3: Test Lokaal

```bash
# Start met Docker (aanbevolen)
docker-compose -f docker-compose.dev.yml up

# OF start direct met Node.js
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) voor het dashboard.

---

## ☁️ Google Cloud Deployment

### Voorbereiding

1. **Maak een Google Cloud account**
   - Ga naar [console.cloud.google.com](https://console.cloud.google.com)
   - Activeer het gratis proefaccount ($300 krediet)
   - Maak een nieuw project (bijv. `mijn-trading-bot`)
   - Noteer je **Project ID** (rechtsboven in de console)

2. **Installeer gcloud CLI**
   ```bash
   # Mac
   brew install --cask google-cloud-sdk

   # Linux
   curl https://sdk.cloud.google.com | bash

   # Windows: download van https://cloud.google.com/sdk/docs/install
   ```

3. **Login bij Google Cloud**
   ```bash
   gcloud auth login
   gcloud config set project JOUW-PROJECT-ID
   ```

### Deploy Script Gebruiken

```bash
# 1. Ga naar je project map
cd bitfinex-trading-bot

# 2. Bewerk deploy.sh en vul je PROJECT_ID in
nano scripts/deploy.sh
# Pas deze regel aan: PROJECT_ID="jouw-project-id"

# 3. Maak het script uitvoerbaar (als dat nog niet is)
chmod +x scripts/deploy.sh

# 4. RUN HET DEPLOYMENT SCRIPT
./scripts/deploy.sh
```

Het script doet alles automatisch:
- ✅ Activeert benodigde API's
- ✅ Maakt firewall regels aan
- ✅ Reserveert een static IP
- ✅ Maakt Ubuntu VM aan
- ✅ Installeert Docker op de VM
- ✅ Bouwt en uploadt je Docker image
- ✅ Start de bot
- ✅ Configureert monitoring & backups

### Na Deployment

```bash
# Check status
./scripts/status.sh

# Dashboard openen
# Het IP adres zie je in de output van deploy.sh
# Of check: gcloud compute instances describe bitfinex-trading-bot --zone=europe-west4-a

# Update bot met nieuwe code
./scripts/update.sh

# Alles verwijderen (OPGELET!)
./scripts/destroy.sh
```

---

## 📊 Beschikbare Strategieën

| Strategie | Markt | Risico | Beschrijving |
|-----------|-------|--------|--------------|
| **Grid** | Sideways | Medium | Koopt laag, verkoopt hoog in een range |
| **DCA** | Any | Laag | Gemiddelde aankoopprijs bij dips |
| **Trend** | Trending | Medium | Volgt trends met Moving Averages |
| **Scalping** | Liquid | Hoog | Snelle trades op kleine bewegingen |
| **Mean Reversion** | Ranging | Medium | Koopt bij lage Bollinger Band |

### Strategie kiezen

Bewerk `.env` op de VM:
```bash
gcloud compute ssh bitfinex-trading-bot --zone=europe-west4-a
nano /opt/trading-bot/.env
# Pas TRADING_STRATEGY=grid aan naar gewenste strategie
docker-compose -f /opt/trading-bot/docker-compose.yml restart
```

---

## 🔒 Veiligheid

### Altijd eerst Paper Trading!

```env
PAPER_TRADING=true          # Simuleert trades (geen echt geld)
ENABLE_LIVE_TRADING=false   # Nog niet inschakelen!
```

Test minimaal 1-2 weken met paper trading. Pas daarna:
```env
PAPER_TRADING=false
ENABLE_LIVE_TRADING=true
```

### Risk Management

| Instelling | Standaard | Functie |
|------------|-----------|---------|
| `MAX_POSITION_VALUE_USD` | 1000 | Max per positie |
| `MAX_DAILY_LOSS_PCT` | 5 | Max dagverlies % |
| `STOP_LOSS_PCT` | 3 | Stop-loss per trade |
| `TAKE_PROFIT_PCT` | 5 | Take-profit per trade |

### Kill Switch

In het dashboard of via API:
```bash
curl -X POST http://VM_IP:3000/api/risk/killswitch
```

Dit stopt ALLE trading onmiddellijk!

---

## 💰 Kostenoverzicht

| Component | Maandkosten |
|-----------|-------------|
| e2-medium VM (2 vCPU, 4GB) | ~$25 |
| 20GB SSD schijf | ~$3 |
| Netwerk | ~$2-5 |
| **Totaal** | **~$30-35/maand** |

**Bespaartips:**
- Gebruik **preemptible instances** voor 60-70% korting
- Zet VM uit als je niet trade (via console of `gcloud compute instances stop`)
- Gebruik het gratis proefaccount ($300 voor 90 dagen)

---

## 🛠️ Handige Commando's

### Lokale ontwikkeling
```bash
npm run dev              # Start met hot-reload
npm test                 # Run tests
docker-compose up        # Start productie versie
```

### VM beheer
```bash
# SSH naar VM
gcloud compute ssh bitfinex-trading-bot --zone=europe-west4-a

# Logs bekijken
gcloud compute ssh bitfinex-trading-bot --zone=europe-west4-a --command="docker logs -f bitfinex-bot"

# Bot herstarten
gcloud compute ssh bitfinex-trading-bot --zone=europe-west4-a --command="docker-compose -f /opt/trading-bot/docker-compose.yml restart"

# VM stoppen (kosten besparen)
gcloud compute instances stop bitfinex-trading-bot --zone=europe-west4-a

# VM starten
gcloud compute instances start bitfinex-trading-bot --zone=europe-west4-a
```

### Database backup
```bash
# Vanaf de VM
cd /opt/trading-bot
cp data/trading.db backups/trading-$(date +%Y%m%d).db
```

---

## 🐛 Troubleshooting

| Probleem | Oplossing |
|----------|-----------|
| "gcloud not found" | Installeer Google Cloud SDK |
| "Docker daemon error" | `sudo usermod -aG docker $USER` en log opnieuw in |
| "Port 3000 in use" | `sudo lsof -i :3000` en kill het proces |
| Dashboard niet bereikbaar | Check firewall regels in GCP Console |
| API errors | Controleer of API keys correct zijn in `.env` |
| VM traag | Upgrade naar `e2-standard-2` of restart VM |
| "Permission denied" | `chmod +x scripts/*.sh` |

---

## 📞 Ondersteuning

- **Bitfinex API Docs**: [docs.bitfinex.com](https://docs.bitfinex.com)
- **Google Cloud Docs**: [cloud.google.com/docs](https://cloud.google.com/docs)
- **Docker Docs**: [docs.docker.com](https://docs.docker.com)

---

## ⚖️ Disclaimer

**TRADE OP EIGEN RISICO.** Deze bot is voor educatieve doeleinden. Crypto trading is inherent riskant. Test altijd eerst met paper trading. De auteurs zijn niet verantwoordelijk voor eventuele verliezen.

---

## 📝 Licentie

MIT License - Vrij te gebruiken en aan te passen.


---

## 📱 iPad Gebruikers

Geen computer? Geen probleem! Volg de **[iPad Deployment Guide](IPAD-GUIDE.md)** om alles vanaf je iPad te deployen via Google Cloud Shell (browser-based terminal).

**Wat je nodig hebt:**
- iPad met Safari
- Google account (gratis)
- Bitfinex account (gratis)
- ~30 minuten tijd

**Geen apps installeren nodig!** Alles werkt in de browser.

---
