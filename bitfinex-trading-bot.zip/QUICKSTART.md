# ⚡ Quick Start Guide

## 1. Setup (1x)
```bash
./scripts/setup.sh
```

## 2. API Keys toevoegen
Bewerk `.env`:
```
BITFINEX_API_KEY=je_key
BITFINEX_API_SECRET=je_secret
```

## 3. Test lokaal
```bash
docker-compose -f docker-compose.dev.yml up
# Open http://localhost:3000
```

## 4. Deploy naar Google Cloud
```bash
# Vul PROJECT_ID in scripts/deploy.sh
nano scripts/deploy.sh

# Deploy!
./scripts/deploy.sh
```

## 5. Dashboard openen
```
http://VM_IP:3000
```

Klaar! 🎉
