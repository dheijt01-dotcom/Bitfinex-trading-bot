#!/bin/bash
# ============================================================================
# Bitfinex Trading Bot - Complete Google Cloud Deployment Script
# ============================================================================
# Dit script deployt de volledige trading bot naar Google Cloud VM
# 
# Gebruik:
#   chmod +x scripts/deploy.sh
#   ./scripts/deploy.sh
#
# Vereisten:
#   - gcloud CLI geinstalleerd (https://cloud.google.com/sdk/docs/install)
#   - Docker geinstalleerd op je lokale machine
#   - Een Google Cloud project aangemaakt
# ============================================================================

set -e  # Stop bij fouten

# Kleuren voor output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color
BOLD='\033[1m'

# ============================================================================
# CONFIGURATIE - PAS DIT AAN NAAR JOUW SITUATIE
# ============================================================================
PROJECT_ID=""                    # Vul in: je GCP project ID (bijv. "mijn-trading-bot")
VM_NAME="bitfinex-trading-bot"   # Naam van je VM
ZONE="europe-west4-a"            # Zone dichtbij jou (NL = europe-west4)
REGION="europe-west4"            # Region voor resources
MACHINE_TYPE="e2-medium"         # e2-medium = 2 vCPU, 4GB RAM (~$25/maand)
DISK_SIZE="20"                   # GB

# Trading configuratie (wordt in .env gezet)
SYMBOL="tBTCUSD"                 # Trading pair
STRATEGY="grid"                  # grid | dca | trend | scalping | meanreversion
PAPER_TRADING="true"             # Altijd true beginnen!
ENABLE_LIVE="false"              # Pas op true zetten na testen

# ============================================================================
# HULPFUNCTIES
# ============================================================================

print_header() {
    echo ""
    echo "${BLUE}${BOLD}═══════════════════════════════════════════════════════════════${NC}"
    echo "${BLUE}${BOLD}  $1${NC}"
    echo "${BLUE}${BOLD}═══════════════════════════════════════════════════════════════${NC}"
}

print_success() {
    echo "${GREEN}✅  $1${NC}"
}

print_warning() {
    echo "${YELLOW}⚠️   $1${NC}"
}

print_error() {
    echo "${RED}❌  $1${NC}"
}

print_info() {
    echo "${BLUE}ℹ️   $1${NC}"
}

# ============================================================================
# STAP 0: VALIDATIE
# ============================================================================

print_header "STAP 0: Validatie"

# Check of gcloud geinstalleerd is
if ! command -v gcloud &> /dev/null; then
    print_error "gcloud CLI is niet geinstalleerd!"
    echo ""
    echo "Installeer het eerst:"
    echo "  Mac:     brew install --cask google-cloud-sdk"
    echo "  Linux:   curl https://sdk.cloud.google.com | bash"
    echo "  Windows: https://cloud.google.com/sdk/docs/install"
    exit 1
fi
print_success "gcloud CLI gevonden"

# Check of Docker geinstalleerd is
if ! command -v docker &> /dev/null; then
    print_error "Docker is niet geinstalleerd!"
    echo "Installeer Docker Desktop: https://www.docker.com/products/docker-desktop"
    exit 1
fi
print_success "Docker gevonden"

# Check of project ID is ingesteld
if [ -z "$PROJECT_ID" ]; then
    print_error "PROJECT_ID is niet ingesteld!"
    echo ""
    echo "Open dit bestand en vul bovenaan je GCP project ID in:"
    echo "  PROJECT_ID="jouw-project-id""
    echo ""
    echo "Je project ID vind je in de Google Cloud Console rechtsboven."
    exit 1
fi

# Check of we ingelogd zijn bij gcloud
if ! gcloud auth list --filter=status:ACTIVE --format="value(account)" | grep -q "@"; then
    print_warning "Je bent niet ingelogd bij Google Cloud"
    echo "Log nu in..."
    gcloud auth login
fi
print_success "Ingelogd bij Google Cloud"

# Check of het project bestaat
if ! gcloud projects describe "$PROJECT_ID" &> /dev/null; then
    print_error "Project '$PROJECT_ID' bestaat niet!"
    echo "Maak eerst een project aan in de Google Cloud Console"
    exit 1
fi
print_success "Project '$PROJECT_ID' gevonden"

# Set project
gcloud config set project "$PROJECT_ID" > /dev/null 2>&1
print_success "Project ingesteld op $PROJECT_ID"

# ============================================================================
# STAP 1: ACTIVEER BENODIGDE API'S
# ============================================================================

print_header "STAP 1: API's activeren"

APIS=(
    "compute.googleapis.com"
    "cloudbuild.googleapis.com"
    "containerregistry.googleapis.com"
    "monitoring.googleapis.com"
    "logging.googleapis.com"
)

for api in "${APIS[@]}"; do
    print_info "Activeren: $api"
    gcloud services enable "$api" --project="$PROJECT_ID" > /dev/null 2>&1 || true
done

print_success "Alle API's geactiveerd"

# ============================================================================
# STAP 2: BUDGET ALERT INSTELLEN (optioneel maar aanbevolen)
# ============================================================================

print_header "STAP 2: Budget alert"

read -p "Wil je een budget alert instellen? (max $50/maand) [j/N]: " set_budget
if [[ $set_budget =~ ^[Jj]$ ]]; then
    gcloud billing budgets create         --display-name="Trading Bot Budget"         --budget-amount=50USD         --threshold-rule=percent=80         --threshold-rule=percent=100         --all-updates-rule-pubsub-topic=""         --quiet 2>/dev/null || print_warning "Budget alert kon niet worden aangemaakt (misschen bestaat al)"
    print_success "Budget alert ingesteld"
else
    print_info "Budget alert overgeslagen"
fi

# ============================================================================
# STAP 3: FIREWALL REGELS
# ============================================================================

print_header "STAP 3: Firewall regels"

# HTTP traffic (poort 80)
if ! gcloud compute firewall-rules describe allow-http --project="$PROJECT_ID" &> /dev/null; then
    gcloud compute firewall-rules create allow-http         --direction=INGRESS         --priority=1000         --network=default         --action=ALLOW         --rules=tcp:80         --source-ranges=0.0.0.0/0         --target-tags=http-server         --quiet > /dev/null 2>&1
    print_success "HTTP firewall regel aangemaakt"
else
    print_info "HTTP firewall regel bestaat al"
fi

# HTTPS traffic (poort 443)
if ! gcloud compute firewall-rules describe allow-https --project="$PROJECT_ID" &> /dev/null; then
    gcloud compute firewall-rules create allow-https         --direction=INGRESS         --priority=1000         --network=default         --action=ALLOW         --rules=tcp:443         --source-ranges=0.0.0.0/0         --target-tags=https-server         --quiet > /dev/null 2>&1
    print_success "HTTPS firewall regel aangemaakt"
else
    print_info "HTTPS firewall regel bestaat al"
fi

# Trading bot dashboard (poort 3000)
if ! gcloud compute firewall-rules describe allow-trading-bot --project="$PROJECT_ID" &> /dev/null; then
    gcloud compute firewall-rules create allow-trading-bot         --direction=INGRESS         --priority=1000         --network=default         --action=ALLOW         --rules=tcp:3000         --source-ranges=0.0.0.0/0         --target-tags=trading-bot         --quiet > /dev/null 2>&1
    print_success "Trading bot firewall regel aangemaakt (poort 3000)"
else
    print_info "Trading bot firewall regel bestaat al"
fi

# SSH toegang beperken (optioneel maar veiliger)
print_info "Tip: Overweeg om SSH toegang te beperken tot jouw IP adres"
MY_IP=$(curl -s ifconfig.me)
print_info "Jouw IP adres is: $MY_IP"
read -p "Wil je SSH toegang beperken tot jouw IP? [j/N]: " restrict_ssh
if [[ $restrict_ssh =~ ^[Jj]$ ]]; then
    gcloud compute firewall-rules create allow-ssh-limited         --direction=INGRESS         --priority=100         --network=default         --action=ALLOW         --rules=tcp:22         --source-ranges="$MY_IP/32"         --target-tags=trading-bot         --quiet > /dev/null 2>&1 || true
    # Verwijder de default allow-ssh regel
    gcloud compute firewall-rules delete default-allow-ssh --quiet > /dev/null 2>&1 || true
    print_success "SSH toegang beperkt tot $MY_IP"
fi

# ============================================================================
# STAP 4: STATIC IP ADRES (optioneel maar aanbevolen)
# ============================================================================

print_header "STAP 4: Static IP adres"

if ! gcloud compute addresses describe bot-static-ip --region="$REGION" --project="$PROJECT_ID" &> /dev/null; then
    gcloud compute addresses create bot-static-ip         --region="$REGION"         --project="$PROJECT_ID"         --quiet > /dev/null 2>&1
    print_success "Static IP aangemaakt"
else
    print_info "Static IP bestaat al"
fi

STATIC_IP=$(gcloud compute addresses describe bot-static-ip --region="$REGION" --format="value(address)" 2>/dev/null || echo "")
print_info "Static IP: $STATIC_IP"

# ============================================================================
# STAP 5: VM INSTANCE AANMAKEN
# ============================================================================

print_header "STAP 5: VM Instance aanmaken"

if gcloud compute instances describe "$VM_NAME" --zone="$ZONE" --project="$PROJECT_ID" &> /dev/null; then
    print_warning "VM '$VM_NAME' bestaat al!"
    read -p "Wil je de bestaande VM verwijderen en opnieuw aanmaken? [j/N]: " recreate
    if [[ $recreate =~ ^[Jj]$ ]]; then
        print_info "VM wordt verwijderd..."
        gcloud compute instances delete "$VM_NAME" --zone="$ZONE" --quiet > /dev/null 2>&1
        print_success "VM verwijderd"
    else
        print_info "Bestaande VM wordt gebruikt"
    fi
fi

# Startup script voor Docker installatie
STARTUP_SCRIPT=$(cat <<'EOF'
#!/bin/bash
set -e

# Log alles
exec > /var/log/startup-script.log 2>&1
set -x

echo "=== STARTUP SCRIPT BEGONNEN ==="

# Update systeem
apt-get update
apt-get upgrade -y

# Installeer benodigde packages
apt-get install -y     apt-transport-https     ca-certificates     curl     gnupg     lsb-release     git     htop     nano     ufw     fail2ban

# Installeer Docker
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null
apt-get update
apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin

# Start Docker
systemctl enable docker
systemctl start docker

# Maak docker-compose symlink
ln -sf /usr/libexec/docker/cli-plugins/docker-compose /usr/local/bin/docker-compose

# Maak gebruiker aan voor de bot
useradd -m -s /bin/bash botuser || true
usermod -aG docker botuser

# Maak directories
mkdir -p /opt/trading-bot/data /opt/trading-bot/logs
chown -R botuser:botuser /opt/trading-bot

# Firewall instellingen (extra beveiliging)
ufw default deny incoming
ufw default allow outgoing
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 3000/tcp
ufw --force enable

# Fail2ban configuratie
cat > /etc/fail2ban/jail.local << 'EOFBAN'
[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 5

[sshd]
enabled = true
port = ssh
filter = sshd
logpath = /var/log/auth.log
EOFBAN

systemctl enable fail2ban
systemctl start fail2ban

echo "=== STARTUP SCRIPT VOLTOOID ==="
EOF
)

# Maak VM aan als deze niet bestaat
if ! gcloud compute instances describe "$VM_NAME" --zone="$ZONE" --project="$PROJECT_ID" &> /dev/null; then
    print_info "VM wordt aangemaakt... (dit duurt ~2 minuten)"

    gcloud compute instances create "$VM_NAME"         --zone="$ZONE"         --machine-type="$MACHINE_TYPE"         --image-family=ubuntu-2204-lts         --image-project=ubuntu-os-cloud         --boot-disk-size="${DISK_SIZE}GB"         --boot-disk-type=pd-standard         --tags=http-server,https-server,trading-bot         --metadata-from-file startup-script=<(echo "$STARTUP_SCRIPT")         --address="$STATIC_IP"         --quiet > /dev/null 2>&1

    print_success "VM '$VM_NAME' aangemaakt!"
else
    print_info "VM bestaat al, ga verder met deployment"
fi

# Wacht tot VM klaar is
print_info "Wachten tot VM opgestart is..."
sleep 30

# Check of VM draait
while ! gcloud compute ssh "$VM_NAME" --zone="$ZONE" --command="echo 'VM is ready'" &> /dev/null; do
    print_info "VM is nog aan het opstarten..."
    sleep 10
done
print_success "VM is operationeel"

# ============================================================================
# STAP 6: DOCKER IMAGE BOUWEN EN UPLOADEN
# ============================================================================

print_header "STAP 6: Docker Image bouwen"

# Configureer Docker voor Google Container Registry
gcloud auth configure-docker gcr.io --quiet > /dev/null 2>&1

IMAGE_TAG="gcr.io/$PROJECT_ID/bitfinex-bot:latest"

print_info "Docker image wordt gebouwd..."
docker build -t "$IMAGE_TAG" . > /tmp/docker-build.log 2>&1

if [ $? -eq 0 ]; then
    print_success "Docker image succesvol gebouwd"
else
    print_error "Docker build mislukt!"
    echo "Bekijk de logs: cat /tmp/docker-build.log"
    exit 1
fi

print_info "Docker image wordt geupload naar Google Container Registry..."
docker push "$IMAGE_TAG" > /tmp/docker-push.log 2>&1

if [ $? -eq 0 ]; then
    print_success "Docker image succesvol geupload"
else
    print_error "Docker push mislukt!"
    echo "Bekijk de logs: cat /tmp/docker-push.log"
    exit 1
fi

# ============================================================================
# STAP 7: CONFIGURATIE NAAR VM KOPIEREN
# ============================================================================

print_header "STAP 7: Configuratie uploaden"

# Maak .env bestand aan als deze niet bestaat
if [ ! -f .env ]; then
    print_warning ".env bestand niet gevonden!"
    print_info "Ik maak een .env bestand aan met standaardwaarden..."

    cat > .env << EOF
# Bitfinex API (VERPLICHT - vul in!)
BITFINEX_API_KEY=je_api_key_hier
BITFINEX_API_SECRET=je_api_secret_hier

# Trading configuratie
TRADING_SYMBOL=$SYMBOL
TRADING_STRATEGY=$STRATEGY
PAPER_TRADING=$PAPER_TRADING
ENABLE_LIVE_TRADING=$ENABLE_LIVE

# Risk Management
MAX_POSITION_VALUE_USD=1000
MAX_DAILY_LOSS_PCT=5
STOP_LOSS_PCT=3
TAKE_PROFIT_PCT=5

# Grid Strategy (alleen als strategy=grid)
GRID_UPPER_PRICE=105000
GRID_LOWER_PRICE=95000
GRID_COUNT=20
GRID_INVESTMENT_USD=5000

# Server
PORT=3000
NODE_ENV=production
EOF

    print_warning "PAS .env AAN MET JE ECHTE API KEYS!"
    print_info "Het bestand is aangemaakt. Bewerk het en run dit script opnieuw."
    exit 1
fi

# Kopieer .env naar VM
print_info "Kopieer .env naar VM..."
gcloud compute scp .env "$VM_NAME":/opt/trading-bot/.env --zone="$ZONE" > /dev/null 2>&1
print_success ".env gekopieerd"

# Kopieer docker-compose.yml
print_info "Kopieer docker-compose.yml naar VM..."
cat > /tmp/docker-compose.yml << EOF
version: '3.8'

services:
  trading-bot:
    image: $IMAGE_TAG
    container_name: bitfinex-bot
    restart: unless-stopped
    ports:
      - "3000:3000"
    env_file:
      - .env
    volumes:
      - ./data:/app/data
      - ./logs:/app/logs
    environment:
      - NODE_ENV=production
    healthcheck:
      test: ["CMD", "wget", "-q", "--spider", "http://localhost:3000/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 10s
    deploy:
      resources:
        limits:
          cpus: '1.0'
          memory: 512M
        reservations:
          cpus: '0.25'
          memory: 128M
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"
EOF

gcloud compute scp /tmp/docker-compose.yml "$VM_NAME":/opt/trading-bot/docker-compose.yml --zone="$ZONE" > /dev/null 2>&1
print_success "docker-compose.yml gekopieerd"

# ============================================================================
# STAP 8: BOT STARTEN OP DE VM
# ============================================================================

print_header "STAP 8: Trading Bot starten"

print_info "SSH naar VM en start de bot..."

gcloud compute ssh "$VM_NAME" --zone="$ZONE" --command="
    cd /opt/trading-bot

    # Pull de nieuwste image
    docker pull $IMAGE_TAG > /dev/null 2>&1

    # Stop bestaande container als die draait
    docker-compose down > /dev/null 2>&1 || true

    # Start de bot
    docker-compose up -d

    # Wacht even en check status
    sleep 5

    if docker ps | grep -q bitfinex-bot; then
        echo 'BOT_IS_RUNNING'
    else
        echo 'BOT_START_FAILED'
        docker-compose logs
    fi
" > /tmp/bot-start.log 2>&1

if grep -q "BOT_IS_RUNNING" /tmp/bot-start.log; then
    print_success "Trading Bot succesvol gestart!"
else
    print_error "Bot kon niet worden gestart!"
    echo "Logs:"
    cat /tmp/bot-start.log
    exit 1
fi

# ============================================================================
# STAP 9: MONITORING INSTELLEN
# ============================================================================

print_header "STAP 9: Monitoring instellen"

# Maak een eenvoudig monitoring script op de VM
gcloud compute ssh "$VM_NAME" --zone="$ZONE" --command="
    cat > /opt/trading-bot/monitor.sh << 'EOFMON'
#!/bin/bash
# Monitoring script - runt elke 5 minuten via cron

LOG_FILE="/opt/trading-bot/logs/monitor.log"
CONTAINER_STATUS=\$(docker ps --filter name=bitfinex-bot --format '{{.Status}}' 2>/dev/null)

if [ -z "\$CONTAINER_STATUS" ]; then
    echo "\$(date): Bot is niet actief! Herstarten..." >> \$LOG_FILE
    cd /opt/trading-bot && docker-compose up -d >> \$LOG_FILE 2>&1
else
    echo "\$(date): Bot draait - \$CONTAINER_STATUS" >> \$LOG_FILE
fi

# Check disk space
DISK_USAGE=\$(df / | tail -1 | awk '{print \$5}' | sed 's/%//')
if [ "\$DISK_USAGE" -gt 80 ]; then
    echo "\$(date): WARNING - Disk usage is \${DISK_USAGE}%" >> \$LOG_FILE
    # Clean up oude logs
    find /opt/trading-bot/logs -name '*.log' -mtime +7 -delete
fi
EOFMON
    chmod +x /opt/trading-bot/monitor.sh

    # Voeg toe aan cron (elke 5 minuten)
    (crontab -l 2>/dev/null; echo "*/5 * * * * /opt/trading-bot/monitor.sh") | crontab -
" > /dev/null 2>&1

print_success "Monitoring ingesteld (checkt elke 5 min)"

# ============================================================================
# STAP 10: BACKUP SCRIPT
# ============================================================================

print_header "STAP 10: Backup configuratie"

gcloud compute ssh "$VM_NAME" --zone="$ZONE" --command="
    cat > /opt/trading-bot/backup.sh << 'EOFBACK'
#!/bin/bash
# Dagelijkse backup van database en logs

BACKUP_DIR="/opt/trading-bot/backups"
DATE=\$(date +%Y%m%d_%H%M%S)
mkdir -p \$BACKUP_DIR

# Backup database
if [ -f /opt/trading-bot/data/trading.db ]; then
    cp /opt/trading-bot/data/trading.db \$BACKUP_DIR/trading_\$DATE.db
    gzip \$BACKUP_DIR/trading_\$DATE.db
fi

# Backup .env
cp /opt/trading-bot/.env \$BACKUP_DIR/env_\$DATE

# Verwijder backups ouder dan 30 dagen
find \$BACKUP_DIR -name '*.db.gz' -mtime +30 -delete
find \$BACKUP_DIR -name 'env_*' -mtime +30 -delete

# Sync naar Google Cloud Storage (optioneel)
# gsutil -m rsync -r \$BACKUP_DIR gs://jouw-backup-bucket/backups/ 2>/dev/null || true
EOFBACK
    chmod +x /opt/trading-bot/backup.sh

    # Dagelijkse backup om 3:00 AM
    (crontab -l 2>/dev/null; echo "0 3 * * * /opt/trading-bot/backup.sh") | crontab -
" > /dev/null 2>&1

print_success "Dagelijkse backups ingesteld (3:00 AM)"

# ============================================================================
# STAP 11: SSL/HTTPS met Let's Encrypt (optioneel)
# ============================================================================

print_header "STAP 11: SSL/HTTPS (optioneel)"

read -p "Wil je HTTPS inschakelen met Let's Encrypt? Vereist een domeinnaam [j/N]: " enable_ssl
if [[ $enable_ssl =~ ^[Jj]$ ]]; then
    read -p "Vul je domeinnaam in (bijv. bot.jouwdomein.nl): " domain

    gcloud compute ssh "$VM_NAME" --zone="$ZONE" --command="
        # Installeer certbot
        apt-get install -y certbot

        # Stop tijdelijk de bot op poort 3000
        docker-compose -f /opt/trading-bot/docker-compose.yml stop

        # Haal certificaat op
        certbot certonly --standalone -d $domain --agree-tos --non-interactive --email admin@$domain

        # Maak nginx reverse proxy
        apt-get install -y nginx

        cat > /etc/nginx/sites-available/trading-bot << EOFNGINX
server {
    listen 80;
    server_name $domain;
    return 301 https://\$server_name\$request_uri;
}

server {
    listen 443 ssl;
    server_name $domain;

    ssl_certificate /etc/letsencrypt/live/$domain/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/$domain/privkey.pem;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
    }
}
EOFNGINX

        ln -sf /etc/nginx/sites-available/trading-bot /etc/nginx/sites-enabled/
        rm -f /etc/nginx/sites-enabled/default
        nginx -t && systemctl restart nginx

        # Start bot weer
        docker-compose -f /opt/trading-bot/docker-compose.yml up -d

        # Auto-renew certificaat
        echo '0 2 * * * certbot renew --quiet && systemctl reload nginx' | crontab -
    " > /dev/null 2>&1

    print_success "HTTPS geconfigureerd voor $domain"
    DASHBOARD_URL="https://$domain"
else
    DASHBOARD_URL="http://$STATIC_IP:3000"
fi

# ============================================================================
# STAP 12: SAMENVATTING
# ============================================================================

print_header "DEPLOYMENT VOLTOOID! 🎉"

echo ""
echo "${GREEN}${BOLD}Je Bitfinex Trading Bot is nu live!${NC}"
echo ""
echo "${BOLD}Dashboard:${NC}     ${BLUE}$DASHBOARD_URL${NC}"
echo "${BOLD}VM Name:${NC}       $VM_NAME"
echo "${BOLD}VM IP:${NC}         $STATIC_IP"
echo "${BOLD}Zone:${NC}          $ZONE"
echo "${BOLD}Project:${NC}       $PROJECT_ID"
echo "${BOLD}Mode:${NC}          ${YELLOW}PAPER TRADING${NC} (veilig testen)"
echo ""
echo "${BOLD}Handige commando's:${NC}"
echo "  SSH naar VM:          gcloud compute ssh $VM_NAME --zone=$ZONE"
echo "  Logs bekijken:        gcloud compute ssh $VM_NAME --zone=$ZONE --command='docker-compose -f /opt/trading-bot/docker-compose.yml logs -f'"
echo "  Bot herstarten:       gcloud compute ssh $VM_NAME --zone=$ZONE --command='docker-compose -f /opt/trading-bot/docker-compose.yml restart'"
echo "  Bot stoppen:          gcloud compute ssh $VM_NAME --zone=$ZONE --command='docker-compose -f /opt/trading-bot/docker-compose.yml down'"
echo ""
echo "${YELLOW}${BOLD}BELANGRIJK:${NC}"
echo "  1. Test eerst met PAPER_TRADING=true (standaard ingesteld)"
echo "  2. Pas .env aan op de VM als je strategie wilt wijzigen:"
echo "     gcloud compute ssh $VM_NAME --zone=$ZONE"
echo "     nano /opt/trading-bot/.env"
echo "     docker-compose -f /opt/trading-bot/docker-compose.yml restart"
echo "  3. Zet pas ENABLE_LIVE_TRADING=true als je 100% zeker bent!"
echo "  4. Monitor je kosten in de Google Cloud Console"
echo ""
echo "${GREEN}Veel succes met traden! 📈${NC}"
echo ""
