#!/bin/bash
# ============================================================================
# Bitfinex Trading Bot - Destroy Script
# Verwijdert ALLE resources van Google Cloud
# WAARSCHUWING: Dit verwijdert alles permanent!
# ============================================================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'
BOLD='\033[1m'

PROJECT_ID=""  # Vul in
VM_NAME="bitfinex-trading-bot"
ZONE="europe-west4-a"
REGION="europe-west4"

echo "${RED}${BOLD}"
echo "╔═══════════════════════════════════════════════════════════════╗"
echo "║  WAARSCHUWING: DIT VERWIJDERT ALLE RESOURCES PERMANENT!      ║"
echo "║                                                               ║"
echo "║  Dit script verwijdert:                                       ║"
echo "║  - VM instance ($VM_NAME)                                     ║"
echo "║  - Firewall regels                                            ║"
echo "║  - Static IP adres                                            ║"
echo "║  - Container Registry images                                  ║"
echo "╚═══════════════════════════════════════════════════════════════╝"
echo "${NC}"

read -p "Typ 'VERWIJDER' om door te gaan: " confirm
if [ "$confirm" != "VERWIJDER" ]; then
    echo "Geannuleerd."
    exit 0
fi

if [ -z "$PROJECT_ID" ]; then
    echo "${RED}PROJECT_ID is niet ingesteld!${NC}"
    exit 1
fi

gcloud config set project "$PROJECT_ID" > /dev/null 2>&1

echo "${YELLOW}VM wordt verwijderd...${NC}"
gcloud compute instances delete "$VM_NAME" --zone="$ZONE" --quiet 2>/dev/null || echo "VM niet gevonden"

echo "${YELLOW}Firewall regels worden verwijderd...${NC}"
gcloud compute firewall-rules delete allow-http --quiet 2>/dev/null || true
gcloud compute firewall-rules delete allow-https --quiet 2>/dev/null || true
gcloud compute firewall-rules delete allow-trading-bot --quiet 2>/dev/null || true
gcloud compute firewall-rules delete allow-ssh-limited --quiet 2>/dev/null || true

echo "${YELLOW}Static IP wordt verwijderd...${NC}"
gcloud compute addresses delete bot-static-ip --region="$REGION" --quiet 2>/dev/null || true

echo "${YELLOW}Container Registry images worden verwijderd...${NC}"
gcloud container images delete gcr.io/$PROJECT_ID/bitfinex-bot:latest --quiet 2>/dev/null || true

echo "${GREEN}✅ Alle resources zijn verwijderd!${NC}"
