#!/bin/bash
# ============================================================================
# Bitfinex Trading Bot - Update Script
# Deployt een nieuwe versie van de bot zonder de VM te verwijderen
# ============================================================================

set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'
BOLD='\033[1m'

PROJECT_ID=""  # Vul in
VM_NAME="bitfinex-trading-bot"
ZONE="europe-west4-a"

if [ -z "$PROJECT_ID" ]; then
    echo "${RED}PROJECT_ID is niet ingesteld! Pas dit script aan.${NC}"
    exit 1
fi

gcloud config set project "$PROJECT_ID" > /dev/null 2>&1

echo "${BLUE}${BOLD}"
echo "═══════════════════════════════════════════════════════════════"
echo "  BITFINEX TRADING BOT - UPDATE"
echo "═══════════════════════════════════════════════════════════════"
echo "${NC}"

# Check of VM bestaat
if ! gcloud compute instances describe "$VM_NAME" --zone="$ZONE" &> /dev/null; then
    echo "${RED}VM '$VM_NAME' niet gevonden! Run eerst deploy.sh${NC}"
    exit 1
fi

# Bouw nieuwe image
IMAGE_TAG="gcr.io/$PROJECT_ID/bitfinex-bot:latest"
echo "${YELLOW}Nieuwe Docker image wordt gebouwd...${NC}"
docker build -t "$IMAGE_TAG" .

echo "${YELLOW}Image wordt geupload...${NC}"
docker push "$IMAGE_TAG"

# Update op VM
echo "${YELLOW}Bot wordt geupdate op VM...${NC}"
gcloud compute ssh "$VM_NAME" --zone="$ZONE" --command="
    cd /opt/trading-bot

    # Backup database
    if [ -f data/trading.db ]; then
        cp data/trading.db backups/trading_$(date +%Y%m%d_%H%M%S).db
    fi

    # Pull nieuwe image
    docker pull $IMAGE_TAG

    # Restart met nieuwe image
    docker-compose down
    docker-compose up -d

    # Cleanup oude images
    docker image prune -f

    echo 'Update voltooid!'
"

echo ""
echo "${GREEN}✅ Bot succesvol geupdate!${NC}"
