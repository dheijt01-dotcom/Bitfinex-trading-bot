#!/bin/bash
# ============================================================================
# Bitfinex Trading Bot - Status Check Script
# Controleert de status van je bot op Google Cloud
# ============================================================================

set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'
BOLD='\033[1m'

PROJECT_ID=""  # Vul in
VM_NAME="bitfinex-trading-bot"
ZONE="europe-west4-a"

if [ -z "$PROJECT_ID" ]; then
    echo "${RED}PROJECT_ID is niet ingesteld! Pas dit script aan.${NC}"
    exit 1
fi

gcloud config set project "$PROJECT_ID" > /dev/null 2>&1

echo "${BLUE}${BOLD}"
echo "═══════════════════════════════════════════════════════════════"
echo "  BITFINEX TRADING BOT - STATUS CHECK"
echo "═══════════════════════════════════════════════════════════════"
echo "${NC}"

# VM Status
echo "${BOLD}VM Status:${NC}"
VM_INFO=$(gcloud compute instances describe "$VM_NAME" --zone="$ZONE" --format="table(status, networkInterfaces[0].accessConfigs[0].natIP, machineType, creationTimestamp)" 2>/dev/null)
if [ -n "$VM_INFO" ]; then
    echo "$VM_INFO"
else
    echo "${RED}VM niet gevonden!${NC}"
fi

echo ""

# Bot Container Status
echo "${BOLD}Bot Container:${NC}"
gcloud compute ssh "$VM_NAME" --zone="$ZONE" --command="
    if docker ps | grep -q bitfinex-bot; then
        echo '${GREEN}✅ Bot is actief${NC}'
        echo ''
        echo 'Container info:'
        docker ps --filter name=bitfinex-bot --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}'
        echo ''
        echo 'Recente logs (laatste 10 regels):'
        docker logs --tail=10 bitfinex-bot 2>/dev/null || echo 'Geen logs beschikbaar'
    else
        echo '${RED}❌ Bot is niet actief${NC}'
        echo ''
        echo 'Alle containers:'
        docker ps -a
    fi
" 2>/dev/null || echo "${RED}Kan niet verbinden met VM${NC}"

echo ""

# Disk Usage
echo "${BOLD}Disk Gebruik:${NC}"
gcloud compute ssh "$VM_NAME" --zone="$ZONE" --command="df -h /" 2>/dev/null || echo "Niet beschikbaar"

echo ""

# Memory Usage
echo "${BOLD}Memory Gebruik:${NC}"
gcloud compute ssh "$VM_NAME" --zone="$ZONE" --command="free -h" 2>/dev/null || echo "Niet beschikbaar"

echo ""

# Netwerk (firewall regels)
echo "${BOLD}Firewall Regels:${NC}"
gcloud compute firewall-rules list --filter="name:(allow-http OR allow-https OR allow-trading-bot)" --format="table(name, direction, allowed, sourceRanges)" 2>/dev/null || echo "Geen firewall regels gevonden"

echo ""
echo "${BLUE}${BOLD}═══════════════════════════════════════════════════════════════${NC}"

# Dashboard URL
STATIC_IP=$(gcloud compute addresses describe bot-static-ip --region="europe-west4" --format="value(address)" 2>/dev/null || echo "")
if [ -n "$STATIC_IP" ]; then
    echo ""
    echo "${GREEN}Dashboard: http://$STATIC_IP:3000${NC}"
fi
