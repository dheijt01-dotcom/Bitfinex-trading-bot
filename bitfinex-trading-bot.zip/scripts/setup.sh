#!/bin/bash
# ============================================================================
# Bitfinex Trading Bot - Lokale Setup Script
# Bereidt je lokale omgeving voor op ontwikkeling
# ============================================================================

set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'
BOLD='\033[1m'

echo "${BLUE}${BOLD}"
echo "═══════════════════════════════════════════════════════════════"
echo "  BITFINEX TRADING BOT - LOKALE SETUP"
echo "═══════════════════════════════════════════════════════════════"
echo "${NC}"

# Check Node.js
if ! command -v node &> /dev/null; then
    echo "${YELLOW}Node.js is niet geinstalleerd. Installeer Node.js 20+:${NC}"
    echo "  Mac:     brew install node"
    echo "  Linux:   curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash - && sudo apt-get install -y nodejs"
    echo "  Windows: https://nodejs.org/"
    exit 1
fi

NODE_VERSION=$(node --version | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 20 ]; then
    echo "${YELLOW}Node.js versie $NODE_VERSION gedetecteerd. Versie 20+ is aanbevolen.${NC}"
fi

print_success "Node.js $(node --version) gevonden"

# Check Docker
if ! command -v docker &> /dev/null; then
    echo "${YELLOW}Docker is niet geinstalleerd. Installeer Docker Desktop:${NC}"
    echo "  https://www.docker.com/products/docker-desktop"
    exit 1
fi
print_success "Docker gevonden"

# Maak directories
mkdir -p data logs backups

# Installeer dependencies
echo "${YELLOW}Dependencies worden geinstalleerd...${NC}"
npm install

# Maak .env als deze niet bestaat
if [ ! -f .env ]; then
    echo "${YELLOW}.env bestand wordt aangemaakt...${NC}"
    cat > .env << 'EOF'
# Bitfinex API (VERPLICHT - vul in!)
BITFINEX_API_KEY=je_api_key_hier
BITFINEX_API_SECRET=je_api_secret_hier

# Trading configuratie
TRADING_SYMBOL=tBTCUSD
TRADING_STRATEGY=grid
PAPER_TRADING=true
ENABLE_LIVE_TRADING=false

# Risk Management
MAX_POSITION_VALUE_USD=1000
MAX_DAILY_LOSS_PCT=5
STOP_LOSS_PCT=3
TAKE_PROFIT_PCT=5

# Grid Strategy
GRID_UPPER_PRICE=105000
GRID_LOWER_PRICE=95000
GRID_COUNT=20
GRID_INVESTMENT_USD=5000

# Server
PORT=3000
NODE_ENV=development
EOF
    echo "${YELLOW}⚠️  PAS .env AAN MET JE ECHTE API KEYS!${NC}"
fi

# Maak scripts uitvoerbaar
chmod +x scripts/*.sh

echo ""
echo "${GREEN}${BOLD}✅ Setup voltooid!${NC}"
echo ""
echo "${BOLD}Volgende stappen:${NC}"
echo "  1. Bewerk .env met je Bitfinex API keys"
echo "  2. Start lokaal:        npm run dev"
echo "  3. Of met Docker:       docker-compose -f docker-compose.dev.yml up"
echo "  4. Open dashboard:      http://localhost:3000"
echo "  5. Deploy naar GCP:     ./scripts/deploy.sh"
echo ""
