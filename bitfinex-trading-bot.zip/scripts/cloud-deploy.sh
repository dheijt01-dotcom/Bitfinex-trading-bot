#!/bin/bash
# ============================================================================
# Bitfinex Trading Bot - Google Cloud Shell Deployment
# ============================================================================
# Dit script is geoptimaliseerd voor gebruik in Google Cloud Shell
# (browser-based terminal, perfect voor iPad!)
#
# GEBRUIK:
#   1. Open Google Cloud Shell (shell.cloud.google.com)
#   2. Clone je repo: git clone https://github.com/JOUW-USERNAME/bitfinex-trading-bot.git
#   3. cd bitfinex-trading-bot
#   4. ./scripts/cloud-deploy.sh
# ============================================================================

set -e

# Kleuren
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'
BOLD='\033[1m'

print_header() {
    echo ""
    echo "${BLUE}${BOLD}═══════════════════════════════════════════════════════════════${NC}"
    echo "${BLUE}${BOLD}  $1${NC}"
    echo "${BLUE}${BOLD}═══════════════════════════════════════════════════════════════${NC}"
}

print_success() { echo "${GREEN}✅  $1${NC}"; }
print_warning() { echo "${YELLOW}⚠️   $1${NC}"; }
print_error() { echo "${RED}❌  $1${NC}"; }
print_info() { echo "${BLUE}ℹ️   $1${NC}"; }

# ============================================================================
# CONFIGURATIE
# ============================================================================

# Vraag om Project ID als het niet is ingesteld
if [ -z "$GOOGLE_CLOUD_PROJECT" ]; then
    echo ""
    echo "${YELLOW}${BOLD}Welkom bij de Bitfinex Trading Bot deployment!${NC}"
    echo ""
    echo "Ik heb je Google Cloud Project ID nodig."
    echo "Je vindt deze in de Google Cloud Console (rechtsboven)."
    echo ""
    read -p "Project ID: " PROJECT_ID

    if [ -z "$PROJECT_ID" ]; then
        print_error "Project ID is verplicht!"
        exit 1
    fi

    gcloud config set project "$PROJECT_ID"
else
    PROJECT_ID="$GOOGLE_CLOUD_PROJECT"
    print_info "Project ID gedetecteerd: $PROJECT_ID"
fi

VM_NAME="bitfinex-trading-bot"
ZONE="europe-west4-a"
REGION="europe-west4"
MACHINE_TYPE="e2-medium"

print_header "Bitfinex Trading Bot Deployment"
print_info "Project: $PROJECT_ID"
print_info "Zone: $ZONE"
print_info "VM: $VM_NAME"

# ============================================================================
# STAP 1: API's ACTIVEREN
# ============================================================================

print_header "STAP 1: API's activeren"

APIS=("compute.googleapis.com" "cloudbuild.googleapis.com")

for api in "${APIS[@]}"; do
    print_info "Activeren: $api"
    gcloud services enable "$api" --quiet 2>/dev/null || true
done

print_success "API's geactiveerd"

# ============================================================================
# STAP 2: FIREWALL REGELS
# ============================================================================

print_header "STAP 2: Firewall regels"

# Poort 3000 voor dashboard
gcloud compute firewall-rules create allow-trading-bot     --allow tcp:3000     --source-ranges=0.0.0.0/0     --target-tags=trading-bot     --quiet 2>/dev/null || print_info "Firewall regel bestaat al"

print_success "Firewall regels OK"

# ============================================================================
# STAP 3: STATIC IP
# ============================================================================

print_header "STAP 3: Static IP"

gcloud compute addresses create bot-static-ip     --region="$REGION"     --quiet 2>/dev/null || print_info "Static IP bestaat al"

STATIC_IP=$(gcloud compute addresses describe bot-static-ip --region="$REGION" --format="value(address)" 2>/dev/null)
print_success "Static IP: $STATIC_IP"

# ============================================================================
# STAP 4: VM AANMAKEN
# ============================================================================

print_header "STAP 4: VM aanmaken"

if gcloud compute instances describe "$VM_NAME" --zone="$ZONE" --quiet 2>/dev/null; then
    print_warning "VM bestaat al. Wordt gebruikt."
else
    print_info "VM wordt aangemaakt..."

    gcloud compute instances create "$VM_NAME"         --zone="$ZONE"         --machine-type="$MACHINE_TYPE"         --image-family=ubuntu-2204-lts         --image-project=ubuntu-os-cloud         --boot-disk-size=20GB         --tags=http-server,https-server,trading-bot         --address="$STATIC_IP"         --metadata=startup-script='#!/bin/bash
            apt-get update
            curl -fsSL https://get.docker.com | sh
            usermod -aG docker ubuntu
            systemctl enable docker
            systemctl start docker
        '         --quiet

    print_success "VM aangemaakt!"
    print_info "Wachten tot VM klaar is..."
    sleep 60
fi

# ============================================================================
# STAP 5: DOCKER IMAGE BOUWEN
# ============================================================================

print_header "STAP 5: Docker Image"

# Configureer Docker auth
gcloud auth configure-docker gcr.io --quiet 2>/dev/null

IMAGE_TAG="gcr.io/$PROJECT_ID/bitfinex-bot:latest"

print_info "Image wordt gebouwd..."
docker build -t "$IMAGE_TAG" . 2>&1 | tail -5

print_info "Image wordt geupload..."
docker push "$IMAGE_TAG" 2>&1 | tail -3

print_success "Image klaar!"

# ============================================================================
# STAP 6: CONFIGURATIE NAAR VM
# ============================================================================

print_header "STAP 6: Configuratie uploaden"

# Check of .env bestaat
if [ ! -f .env ]; then
    print_warning ".env niet gevonden!"
    print_info "Ik maak een standaard .env aan..."
    cat > .env << 'EOF'
BITFINEX_API_KEY=VUL_IN
BITFINEX_API_SECRET=VUL_IN
PAPER_TRADING=true
ENABLE_LIVE_TRADING=false
TRADING_SYMBOL=tBTCUSD
TRADING_STRATEGY=grid
MAX_POSITION_VALUE_USD=1000
STOP_LOSS_PCT=3
TAKE_PROFIT_PCT=5
EOF
    print_warning "PAS .env AAN MET JE ECHTE API KEYS!"
    print_info "Bewerk het bestand: nano .env"
    print_info "En run dit script opnieuw."
    exit 1
fi

# Kopieer bestanden naar VM
print_info "Bestanden worden gekopieerd..."
gcloud compute scp .env "$VM_NAME":/home/ubuntu/.env --zone="$ZONE" --quiet
gcloud compute ssh "$VM_NAME" --zone="$ZONE" --quiet --command="sudo mkdir -p /opt/trading-bot && sudo mv /home/ubuntu/.env /opt/trading-bot/"

# Maak docker-compose.yml op VM
gcloud compute ssh "$VM_NAME" --zone="$ZONE" --quiet --command="sudo tee /opt/trading-bot/docker-compose.yml > /dev/null << 'EOF'
version: '3.8'
services:
  trading-bot:
    image: $IMAGE_TAG
    container_name: bitfinex-bot
    restart: unless-stopped
    ports:
      - '3000:3000'
    env_file:
      - .env
    volumes:
      - ./data:/app/data
      - ./logs:/app/logs
EOF"

print_success "Configuratie geupload!"

# ============================================================================
# STAP 7: BOT STARTEN
# ============================================================================

print_header "STAP 7: Bot starten"

print_info "Bot wordt gestart op VM..."
gcloud compute ssh "$VM_NAME" --zone="$ZONE" --quiet --command="
    cd /opt/trading-bot
    sudo docker pull $IMAGE_TAG
    sudo docker-compose down 2>/dev/null || true
    sudo docker-compose up -d
    sleep 5
    sudo docker ps | grep bitfinex-bot && echo 'BOT_RUNNING' || echo 'BOT_FAILED'
" > /tmp/bot-status.txt 2>&1

if grep -q "BOT_RUNNING" /tmp/bot-status.txt; then
    print_success "Bot draait!"
else
    print_error "Bot startte niet correct"
    cat /tmp/bot-status.txt
fi

# ============================================================================
# STAP 8: SAMENVATTING
# ============================================================================

print_header "DEPLOYMENT VOLTOOID! 🎉"

echo ""
echo "${GREEN}${BOLD}Je Bitfinex Trading Bot is nu live!${NC}"
echo ""
echo "${BOLD}🌐 Dashboard:${NC}     ${BLUE}http://$STATIC_IP:3000${NC}"
echo "${BOLD}📍 VM IP:${NC}         $STATIC_IP"
echo "${BOLD}🔧 SSH:${NC}           gcloud compute ssh $VM_NAME --zone=$ZONE"
echo ""
echo "${YELLOW}${BOLD}⚠️  BELANGRIJK:${NC}"
echo "  • PAPER_TRADING staat op TRUE (veilig testen)"
echo "  • Pas .env aan op de VM voor live trading"
echo "  • Monitor je kosten in de GCP Console"
echo ""
echo "${BOLD}Handige commando's:${NC}"
echo "  Logs:     gcloud compute ssh $VM_NAME --zone=$ZONE --command='sudo docker logs -f bitfinex-bot'"
echo "  Stop:     gcloud compute instances stop $VM_NAME --zone=$ZONE"
echo "  Start:    gcloud compute instances start $VM_NAME --zone=$ZONE"
echo ""
echo "${GREEN}Veel succes met traden! 📈${NC}"
