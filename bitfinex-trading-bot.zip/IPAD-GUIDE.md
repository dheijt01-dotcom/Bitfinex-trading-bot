# 📱 Bitfinex Trading Bot - iPad Deployment Guide

Deze guide is speciaal geschreven voor iPad gebruikers. Je hebt **geen computer** nodig — alles gebeurt via de browser en Google Cloud Shell.

---

## 🛠️ Wat je nodig hebt

| Apparatuur | Vereist |
|-----------|---------|
| iPad (elke versie) | ✅ |
| Toetsenbord (aanbevolen) | Optioneel |
| Safari of Chrome | ✅ |
| Google account | ✅ (gratis) |
| Bitfinex account | ✅ (gratis) |

**Geen apps installeren nodig!** Alles werkt in de browser.

---

## 🚀 Stap-voor-stap Deployment (vanaf je iPad)

### Stap 1: Maak een GitHub repository aan (2 min)

1. Open Safari op je iPad
2. Ga naar [github.com](https://github.com)
3. Log in of maak een gratis account aan
4. Tik op het **+** icoontje (rechtsboven) → **New repository**
5. Vul in:
   - **Repository name**: `bitfinex-trading-bot`
   - **Description**: `Crypto trading bot for Bitfinex`
   - **Public** of **Private** (maakt niet uit)
   - ✅ Vinkje bij **Add a README file**
6. Tik op **Create repository**

### Stap 2: Upload de bot code naar GitHub (3 min)

1. In je nieuwe repository, tik op **Add file** → **Upload files**
2. Tik op **choose your files**
3. Selecteer ALLE bestanden uit het `bitfinex-trading-bot` project:
   - `src/` map (met alle .js bestanden)
   - `scripts/` map
   - `Dockerfile`
   - `docker-compose.yml`
   - `package.json`
   - `.env.example`
   - `.gitignore`
4. Scroll naar beneden en tik op **Commit changes**

*Tip: Je kunt ook de bestanden stuk voor stuk plakken via "Create new file" als uploaden niet lukt.*

### Stap 3: Maak een Google Cloud account aan (3 min)

1. Ga naar [console.cloud.google.com](https://console.cloud.google.com) in Safari
2. Log in met je Google account
3. Accepteer de voorwaarden
4. Je krijgt automatisch **$300 gratis krediet** voor 90 dagen
5. Maak een **nieuw project**:
   - Tik op het project dropdown (bovenaan)
   - **New Project**
   - **Project name**: `bitfinex-bot`
   - **Create**
6. Noteer je **Project ID** (staat onder de project naam, bijv. `bitfinex-bot-123456`)

### Stap 4: Open Google Cloud Shell (1 min)

1. In de Google Cloud Console, tik op het **Terminal icoontje** (rechtsboven, ziet eruit als `>_`)
   - Of ga direct naar [shell.cloud.google.com](https://shell.cloud.google.com)
2. Wacht tot de terminal geladen is (dit duurt ~30 seconden)
3. Je ziet nu een zwart terminal venster in je browser

### Stap 5: Clone je repository in Cloud Shell (1 min)

Plak dit commando in de Cloud Shell terminal:

```bash
git clone https://github.com/JOUW-GITHUB-USERNAME/bitfinex-trading-bot.git
cd bitfinex-trading-bot
```

*Vervang `JOUW-GITHUB-USERNAME` door je echte GitHub gebruikersnaam*

### Stap 6: Configureer je bot (2 min)

Plak deze commando's een voor een:

```bash
# Kopieer het voorbeeld .env bestand
cp .env.example .env

# Bewerk het .env bestand
nano .env
```

Je ziet nu een teksteditor. Pas deze regels aan:

```
BITFINEX_API_KEY=je_echte_api_key
BITFINEX_API_SECRET=je_echte_api_secret
PAPER_TRADING=true
ENABLE_LIVE_TRADING=false
```

**Hoe krijg je API keys?**
1. Open een nieuw Safari tabblad
2. Ga naar [bitfinex.com](https://www.bitfinex.com) → **Account → API**
3. Maak een nieuwe API key
4. Geef rechten: **Orders**, **Wallets**, **Account Info**
5. Kopieer de key en secret
6. Plak ze in het .env bestand in Cloud Shell

**Nano editor tips op iPad:**
- Tik op het scherm om de cursor te verplaatsen
- Gebruik het toetsenbord om te typen
- Druk `Ctrl + O` om op te slaan (tik op `^` en dan `O` in de on-screen toolbar)
- Druk `Ctrl + X` om af te sluiten

### Stap 7: Run het deployment script (5 min)

Plak dit commando in Cloud Shell:

```bash
chmod +x scripts/cloud-deploy.sh
./scripts/cloud-deploy.sh
```

Het script vraagt om je **Project ID**:
- Tik je Project ID in (bijv. `bitfinex-bot-123456`)
- Druk Enter

Nu doet het script alles automatisch:
- ✅ Activeert API's
- ✅ Maakt firewall regels
- ✅ Reserveert een static IP
- ✅ Maakt Ubuntu VM aan
- ✅ Installeert Docker
- ✅ Bouwt en uploadt je image
- ✅ Start de bot

**Dit duurt ~5 minuten.** Wacht geduldig af.

### Stap 8: Open je dashboard! 🎉

Als het script klaar is, zie je:

```
🎉 DEPLOYMENT VOLTOOID!
Dashboard: http://34.91.123.45:3000
```

1. Kopieer het IP adres
2. Open een nieuw Safari tabblad
3. Plak het adres + `:3000`
4. Je ziet nu het **Trading Bot Dashboard**!

---

## 📱 Dashboard gebruiken op je iPad

Het dashboard is volledig responsive en werkt perfect op iPad:

| Functie | Hoe? |
|---------|------|
| **Bot starten/stoppen** | Tik op de Start/Stop knoppen |
| **Strategie wijzigen** | Selecteer uit het dropdown menu |
| **Kill switch** | Tik op de rode "Kill Switch" knop |
| **P&L bekijken** | Scroll naar de Performance sectie |
| **Logs bekijken** | Scroll naar beneden voor live logs |

---

## 🔧 Dagelijks beheer (vanaf je iPad)

### Status checken

1. Open [shell.cloud.google.com](https://shell.cloud.google.com)
2. Plak:
```bash
cd ~/bitfinex-trading-bot
./scripts/status.sh
```

### Bot updaten met nieuwe code

1. Werk je code bij in GitHub (via Safari)
2. Open Cloud Shell
3. Plak:
```bash
cd ~/bitfinex-trading-bot
git pull
./scripts/update.sh
```

### Logs bekijken

1. Open Cloud Shell
2. Plak:
```bash
gcloud compute ssh bitfinex-trading-bot --zone=europe-west4-a --command="docker logs -f bitfinex-bot"
```

### Bot stoppen (kosten besparen)

1. Open Cloud Shell
2. Plak:
```bash
gcloud compute instances stop bitfinex-trading-bot --zone=europe-west4-a
```

### Bot weer starten

```bash
gcloud compute instances start bitfinex-trading-bot --zone=europe-west4-a
```

### Alles verwijderen

⚠️ **Dit verwijdert ALLES permanent!**

```bash
cd ~/bitfinex-trading-bot
./scripts/destroy.sh
```

---

## 💡 iPad Tips

### Split Screen gebruiken

1. Open Safari met je dashboard
2. Swipe vanaf de onderkant om de Dock te zien
3. Sleep Cloud Shell (of een andere app) naar de linkerkant
4. Nu heb je dashboard + terminal naast elkaar!

### Cloud Shell bookmarken

1. Ga naar [shell.cloud.google.com](https://shell.cloud.google.com)
2. Tik op de **Delen** knop in Safari
3. Kies **Zet op beginscherm**
4. Nu heb je een snelkoppeling op je home screen!

---

## 🆘 Problemen oplossen

| Probleem | Oplossing |
|----------|-----------|
| "Project ID niet gevonden" | Controleer of je het juiste Project ID hebt ingevuld |
| "Permission denied" | Run `chmod +x scripts/cloud-deploy.sh` voor je het script draait |
| Dashboard niet bereikbaar | Wacht 2 minuten na deployment, check firewall regels in GCP Console |
| "Docker not found" | Het startup script installeert Docker automatisch, wacht 3 minuten |
| Cloud Shell sluit na inactiviteit | Herstart Cloud Shell, je data blijft bewaard |
| Nano editor werkt raar op iPad | Gebruik `vi` in plaats van `nano`: `vi .env` |

---

## 💰 Kosten

| Component | Per maand |
|-----------|-----------|
| e2-medium VM | ~$25 |
| 20GB schijf | ~$3 |
| Netwerk | ~$2-5 |
| **Totaal** | **~$30-35** |

**Gratis proefaccount**: $300 voor 90 dagen = ~9 maanden gratis!

**Kosten besparen**:
- Stop de VM als je niet trade: `gcloud compute instances stop bitfinex-trading-bot --zone=europe-west4-a`
- Start weer: `gcloud compute instances start bitfinex-trading-bot --zone=europe-west4-a`
- Je betaalt alleen voor de schijf (~$3/maand) als de VM uit staat
